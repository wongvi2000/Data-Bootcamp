
## Plot Sentiments


```python
# Dependencies
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json
import tweepy
import time
import seaborn as sns
from config import consumer_key, consumer_secret,  access_token, access_token_secret
```


```python
# Initialize Sentiment Analyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()
```


```python
# Setup Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, wait_on_rate_limit=True)
```


```python
# Target Account 1
target_userCNN = "CNN"

# Counter
counter = 1

# Variables for holding sentiments
sentimentsCNN = []

public_tweetsCNN = api.user_timeline(target_userCNN, count=100)


# Loop through all tweets 
for status in public_tweetsCNN:
    # Print Tweets
    # print("Tweet %s: %s" % (counter, tweet["text"]))

    tweet = status._json
    # Run Vader Analysis on each tweet
    compound = analyzer.polarity_scores(tweet["text"])["compound"]
    pos = analyzer.polarity_scores(tweet["text"])["pos"]
    neu = analyzer.polarity_scores(tweet["text"])["neu"]
    neg = analyzer.polarity_scores(tweet["text"])["neg"]
    tweets_ago = counter

    # Add sentiments for each tweet into an array
    sentimentsCNN.append({"Date": tweet["created_at"], 
                       "Compound": compound,
                       "Positive": pos,
                       "Negative": neu,
                       "Neutral": neg,
                       "Tweets Ago": counter})

    # Add to counter 
    counter = counter + 1

```


```python
# Target Account 2
target_userNYT = "@nytimes" 

# Counter
counter = 1

# Variables for holding sentiments
sentimentsNYT = []

public_tweetsNYT = api.user_timeline(target_userNYT, count=100)

# Loop through all tweets 
for status in public_tweetsNYT:
    # Print Tweets
    # print("Tweet %s: %s" % (counter, tweet["text"]))

    tweet = status._json
    # Run Vader Analysis on each tweet
    compound = analyzer.polarity_scores(tweet["text"])["compound"]
    pos = analyzer.polarity_scores(tweet["text"])["pos"]
    neu = analyzer.polarity_scores(tweet["text"])["neu"]
    neg = analyzer.polarity_scores(tweet["text"])["neg"]
    tweets_ago = counter

    # Add sentiments for each tweet into an array
    sentimentsNYT.append({"Date": tweet["created_at"], 
                       "Compound": compound,
                       "Positive": pos,
                       "Negative": neu,
                       "Neutral": neg,
                       "Tweets Ago": counter})

    # Add to counter 
    counter = counter + 1
```


```python
# Target Account 3
target_userBBC = "@BBCNews"

# Counter
counter = 1

# Variables for holding sentiments
sentimentsBBC = []

public_tweetsBBC = api.user_timeline(target_userBBC, count=100)

# Loop through all tweets 
for status in public_tweetsBBC:
    # Print Tweets
    # print("Tweet %s: %s" % (counter, tweet["text"]))

    tweet = status._json
    # Run Vader Analysis on each tweet
    compound = analyzer.polarity_scores(tweet["text"])["compound"]
    pos = analyzer.polarity_scores(tweet["text"])["pos"]
    neu = analyzer.polarity_scores(tweet["text"])["neu"]
    neg = analyzer.polarity_scores(tweet["text"])["neg"]
    tweets_ago = counter

    # Add sentiments for each tweet into an array
    sentimentsBBC.append({"Date": tweet["created_at"], 
                       "Compound": compound,
                       "Positive": pos,
                       "Negative": neu,
                       "Neutral": neg,
                       "Tweets Ago": counter})

    # Add to counter 
    counter = counter + 1
```


```python
# Target Account 4
target_userFOX = "@FoxNews"

# Counter
counter = 1

# Variables for holding sentiments
sentimentsFOX = []

public_tweetsFOX = api.user_timeline(target_userFOX, count=100)

# Loop through all tweets 
for status in public_tweetsFOX:
    # Print Tweets
    # print("Tweet %s: %s" % (counter, tweet["text"]))

    tweet = status._json
    # Run Vader Analysis on each tweet
    compound = analyzer.polarity_scores(tweet["text"])["compound"]
    pos = analyzer.polarity_scores(tweet["text"])["pos"]
    neu = analyzer.polarity_scores(tweet["text"])["neu"]
    neg = analyzer.polarity_scores(tweet["text"])["neg"]
    tweets_ago = counter

    # Add sentiments for each tweet into an array
    sentimentsFOX.append({"Date": tweet["created_at"], 
                       "Compound": compound,
                       "Positive": pos,
                       "Negative": neu,
                       "Neutral": neg,
                       "Tweets Ago": counter})

    # Add to counter 
    counter = counter + 1
```


```python
# Target Account 5
target_userCBS = "@CBSNews"

# Counter
counter = 1

# Variables for holding sentiments
sentimentsCBS = []

public_tweetsCBS = api.user_timeline(target_userCBS, count=100)

# Loop through all tweets 
for status in public_tweetsCBS:
    # Print Tweets
    # print("Tweet %s: %s" % (counter, tweet["text"]))

    tweet = status._json
    # Run Vader Analysis on each tweet
    compound = analyzer.polarity_scores(tweet["text"])["compound"]
    pos = analyzer.polarity_scores(tweet["text"])["pos"]
    neu = analyzer.polarity_scores(tweet["text"])["neu"]
    neg = analyzer.polarity_scores(tweet["text"])["neg"]
    tweets_ago = counter

    # Add sentiments for each tweet into an array
    sentimentsCBS.append({"Date": tweet["created_at"], 
                       "Compound": compound,
                       "Positive": pos,
                       "Negative": neu,
                       "Neutral": neg,
                       "Tweets Ago": counter})

    # Add to counter 
    counter = counter + 1
```


```python
# Convert sentiments to DataFrame
sentimentsCBS_pd = pd.DataFrame.from_dict(sentimentsCBS)
sentimentsFOX_pd = pd.DataFrame.from_dict(sentimentsFOX)
sentimentsBBC_pd = pd.DataFrame.from_dict(sentimentsBBC)
sentimentsNYT_pd = pd.DataFrame.from_dict(sentimentsNYT)
sentimentsCNN_pd = pd.DataFrame.from_dict(sentimentsCNN)
```


```python
sentimentsCBS_pd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0000</td>
      <td>Mon Apr 09 20:19:29 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.6369</td>
      <td>Mon Apr 09 20:06:45 +0000 2018</td>
      <td>0.600</td>
      <td>0.304</td>
      <td>0.096</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.0000</td>
      <td>Mon Apr 09 20:00:02 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-0.6369</td>
      <td>Mon Apr 09 19:40:01 +0000 2018</td>
      <td>0.500</td>
      <td>0.380</td>
      <td>0.120</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.6908</td>
      <td>Mon Apr 09 19:30:02 +0000 2018</td>
      <td>0.749</td>
      <td>0.251</td>
      <td>0.000</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
sentimentsFOX_pd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.6369</td>
      <td>Mon Apr 09 20:17:40 +0000 2018</td>
      <td>0.792</td>
      <td>0.208</td>
      <td>0.000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.5106</td>
      <td>Mon Apr 09 20:08:00 +0000 2018</td>
      <td>0.552</td>
      <td>0.325</td>
      <td>0.123</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.0000</td>
      <td>Mon Apr 09 19:58:40 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0000</td>
      <td>Mon Apr 09 19:51:11 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0000</td>
      <td>Mon Apr 09 19:40:00 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
sentimentsBBC_pd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.7845</td>
      <td>Mon Apr 09 20:08:24 +0000 2018</td>
      <td>0.655</td>
      <td>0.345</td>
      <td>0.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.2732</td>
      <td>Mon Apr 09 18:44:47 +0000 2018</td>
      <td>0.741</td>
      <td>0.259</td>
      <td>0.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.3182</td>
      <td>Mon Apr 09 17:33:37 +0000 2018</td>
      <td>0.796</td>
      <td>0.204</td>
      <td>0.0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-0.2023</td>
      <td>Mon Apr 09 16:58:41 +0000 2018</td>
      <td>0.795</td>
      <td>0.205</td>
      <td>0.0</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0000</td>
      <td>Mon Apr 09 16:58:00 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
sentimentsNYT_pd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0258</td>
      <td>Mon Apr 09 20:20:05 +0000 2018</td>
      <td>0.939</td>
      <td>0.000</td>
      <td>0.061</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.0000</td>
      <td>Mon Apr 09 20:10:06 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.3818</td>
      <td>Mon Apr 09 20:06:34 +0000 2018</td>
      <td>0.746</td>
      <td>0.184</td>
      <td>0.070</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0000</td>
      <td>Mon Apr 09 20:04:49 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0000</td>
      <td>Mon Apr 09 20:02:36 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
sentimentsCNN_pd.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.0000</td>
      <td>Mon Apr 09 20:19:46 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.4939</td>
      <td>Mon Apr 09 19:59:45 +0000 2018</td>
      <td>0.868</td>
      <td>0.000</td>
      <td>0.132</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.0000</td>
      <td>Mon Apr 09 19:52:46 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-0.4019</td>
      <td>Mon Apr 09 19:39:14 +0000 2018</td>
      <td>0.731</td>
      <td>0.174</td>
      <td>0.096</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0000</td>
      <td>Mon Apr 09 19:33:53 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Create plot
CBS = plt.scatter(np.arange(len(sentimentsCBS_pd["Compound"])),
         sentimentsCBS_pd["Compound"], marker="o", linewidth=0.5,
         alpha=0.8)
FOX = plt.scatter(np.arange(len(sentimentsFOX_pd["Compound"])),
         sentimentsFOX_pd["Compound"], marker="o", linewidth=0.5,
         alpha=0.8)
BBC = plt.scatter(np.arange(len(sentimentsBBC_pd["Compound"])),
         sentimentsBBC_pd["Compound"], marker="o", linewidth=0.5,
         alpha=0.8)
NYT = plt.scatter(np.arange(len(sentimentsNYT_pd["Compound"])),
         sentimentsNYT_pd["Compound"], marker="o", linewidth=0.5,
         alpha=0.8)
CNN = plt.scatter(np.arange(len(sentimentsCNN_pd["Compound"])),
         sentimentsCNN_pd["Compound"], marker="o", linewidth=0.5,
         alpha=0.8)

# # Incorporate the other graph properties
plt.title("Sentiment Analysis of Media Tweets (04-09-2018)")
plt.ylabel("Tweet Polarity")
plt.xlabel("Tweets Ago")
plt.legend((CBS, FOX, BBC, NYT, CNN), ("CBS", "FOX", "BBC", "NYT", "CNN"), scatterpoints=1, loc="lower left", ncol=1, fontsize=8)
plt.show()
```


![png](output_15_0.png)



```python
plt.savefig("VWongHmwk#7_SentimentAnalysis.png")
```


    <matplotlib.figure.Figure at 0xe537860>



```python
meanCBS = sentimentsCBS_pd["Compound"].mean()
print(meanCBS)
meanFOX = sentimentsFOX_pd["Compound"].mean()  
print(meanFOX)
meanBBC = sentimentsBBC_pd["Compound"].mean()
print(meanBBC)
meanNYT = sentimentsNYT_pd["Compound"].mean()  
print(meanNYT)
meanCNN = sentimentsCNN_pd["Compound"].mean()  
print(meanCNN)
```

    -0.15054800000000004
    -0.09982300000000002
    -0.020800000000000027
    -0.007283999999999993
    -0.155424
    


```python
Media_Outlets = ["CBS", "FOX", "BBC", "NYT", "CNN"]
Tweet_Polarity = [meanCBS, meanFOX, meanBBC, meanNYT, meanCNN]
print(Tweet_Polarity)
```

    [-0.15054800000000004, -0.09982300000000002, -0.020800000000000027, -0.007283999999999993, -0.155424]
    


```python
media_tweetpolarity = [{"Media":"CBS", "MeanPolarity":meanCBS},{"Media":"Fox", "MeanPolarity":meanFOX}, {"Media":"BBC", "MeanPolarity":meanBBC},{"Media":"NYT", "MeanPolarity":meanNYT},{"Media":"CNN", "MeanPolarity":meanCNN}]
print (media_tweetpolarity)
```

    [{'Media': 'CBS', 'MeanPolarity': -0.15054800000000004}, {'Media': 'Fox', 'MeanPolarity': -0.09982300000000002}, {'Media': 'BBC', 'MeanPolarity': -0.020800000000000027}, {'Media': 'NYT', 'MeanPolarity': -0.007283999999999993}, {'Media': 'CNN', 'MeanPolarity': -0.155424}]
    


```python
media_tweetpolarity_df = pd.DataFrame(media_tweetpolarity)
media_tweetpolarity_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MeanPolarity</th>
      <th>Media</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.150548</td>
      <td>CBS</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.099823</td>
      <td>Fox</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.020800</td>
      <td>BBC</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-0.007284</td>
      <td>NYT</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.155424</td>
      <td>CNN</td>
    </tr>
  </tbody>
</table>
</div>




```python
media_tweetpolarity_df.plot(kind="bar", x="Media", y="MeanPolarity", title="Overall Media Sentiment based on Twitter 04-09-2018")
```




    <matplotlib.axes._subplots.AxesSubplot at 0xe393160>




![png](output_21_1.png)



```python
plt.savefig("VWongHmwk#7_MeanPolarity.png")
```


    <matplotlib.figure.Figure at 0xce059e8>



```python
media_tweetpolarity_df.to_csv('media_tweetpolarity.csv') 
```
