

```python
#Import dependencies - python libraries
import pandas as pd
import numpy as np
import requests
import json
import openweathermapy.core as owm
import pprint 
import matplotlib.pyplot as plt
import seaborn as sns
from numpy import random
from citipy import citipy

#First is to run thru the example of calculation for 1 city using citipy and openweathermapy libraries & API calls
```


```python
#Import API key for WeatherAPI
from config import weather_api_key
```


```python
#Settings for WeatherAPI
settings = {"units": "Imperial", "appid": weather_api_key}
```


```python
#Creation of the 500 cities randomly with the above measurements
#Define the list to store information of weather by city
lat = []
lon = []
cities = []
cities_id = []
temp = []
humidity = []
cloudiness = []
windspeed = []
mylist = []
#OpenWeatherMap API Url
url = "http://api.openweathermap.org/data/2.5/weather?"
```


```python
for x in range(1,1800):
    try:
        #   print(x)
        L1 = random.randint(-90,90)
        L2 = random.randint(-180,180)
        city = citipy.nearest_city(L1, L2)
        cityname = city.city_name
        current_weather = owm.get_current(cityname, **settings)
        tempsummary = ["main.temp_max"]
        humsummary = ["main.humidity"]
        cloudsummary = ["clouds.all"]
        windsummary = ["wind.speed"]
        cityidsummary = ["id"]
        latsummary = ["coord.lat"]
        lonsummary = ["coord.lon"]
        temp1 = current_weather(*tempsummary)
        humidity1 = current_weather(*humsummary)
        cloudiness1 = current_weather(*cloudsummary)
        windspeed1 = current_weather(*windsummary)
        cityid1 = current_weather(*cityidsummary)
        lat1 = current_weather(*latsummary) 
        lon1 = current_weather(*lonsummary)
        query_url = url + "appid=" + "api_key" + "&q=" + cityname
        lat.append(int(lat1)) 
        lon.append(int(lon1)) 
        temp.append(int(temp1))
        humidity.append(int(humidity1))
        cloudiness.append(int(cloudiness1) )
        windspeed.append(int(windspeed1) )
        cities.append(str(cityname))
        cities_id.append(int(cityid1))
        print(f"City{x}= {cityname}, city id = {cityid1}, temp = {temp1}F, url ={query_url}")
        mylist.append({"city": cityname, "city_id": cityid1, "lat": lat1, "lon": lon1, "temp": temp1, "humidity": humidity1, "cloudiness": cloudiness1, "windspeed": windspeed1})
        #print(mylist)
    except Exception as err:
        pass
```

    City1= pevek, city id = 2122090, temp = 25.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pevek
    City2= tilichiki, city id = 2120591, temp = 33.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tilichiki
    City3= yuza, city id = 1848016, temp = 50F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yuza
    City5= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City6= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City7= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City8= hay river, city id = 5972762, temp = 15.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hay river
    City9= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City10= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City11= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City12= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City13= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City14= comodoro rivadavia, city id = 3860443, temp = 69.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=comodoro rivadavia
    City15= dudinka, city id = 1507116, temp = -7.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dudinka
    City16= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City17= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City21= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City23= kahului, city id = 5847411, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kahului
    City24= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City26= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City27= nagai, city id = 2111781, temp = 48.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nagai
    City28= mitsamiouli, city id = 921786, temp = 80.79F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mitsamiouli
    City29= pevek, city id = 2122090, temp = 25.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pevek
    City30= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City31= esperance, city id = 3573739, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=esperance
    City32= pevek, city id = 2122090, temp = 25.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pevek
    City33= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City34= aviles, city id = 3129135, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aviles
    City35= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City36= bonthe, city id = 2409914, temp = 79.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bonthe
    City37= kieta, city id = 2094027, temp = 83.76F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kieta
    City39= ribeira grande, city id = 3372707, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ribeira grande
    City40= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City41= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City42= carandai, city id = 3467026, temp = 68F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carandai
    City43= amuntai, city id = 1651461, temp = 77.46F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=amuntai
    City44= yulara, city id = 6355222, temp = 86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yulara
    City45= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City46= kui buri, city id = 1152562, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kui buri
    City48= pachino, city id = 6539213, temp = 57.3F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pachino
    City49= nanortalik, city id = 3421765, temp = 34.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nanortalik
    City50= jiamusi, city id = 2036581, temp = 54.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jiamusi
    City51= caruray, city id = 1718234, temp = 80.97F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=caruray
    City52= ust-kulom, city id = 478050, temp = 16.71F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ust-kulom
    City53= beloha, city id = 1067565, temp = 74.9F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=beloha
    City54= torbay, city id = 6167817, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=torbay
    City55= pevek, city id = 2122090, temp = 25.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pevek
    City56= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City57= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City58= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City59= lipari, city id = 2524379, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lipari
    City60= barinas, city id = 3648546, temp = 87.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barinas
    City61= pisco, city id = 3932145, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pisco
    City62= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City63= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City64= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City65= mirnyy, city id = 502265, temp = 36.51F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mirnyy
    City66= salinopolis, city id = 3389822, temp = 78.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=salinopolis
    City67= carnarvon, city id = 1014034, temp = 54.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carnarvon
    City68= rundu, city id = 3353383, temp = 71.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rundu
    City69= te anau, city id = 2181625, temp = 61.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=te anau
    City71= umm kaddadah, city id = 364933, temp = 65.99F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=umm kaddadah
    City72= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City73= iqaluit, city id = 5983720, temp = 5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=iqaluit
    City74= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City75= areia branca, city id = 3471609, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=areia branca
    City76= bambous virieux, city id = 1106677, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bambous virieux
    City77= tigil, city id = 2120612, temp = 32.01F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tigil
    City79= acapulco, city id = 3533462, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=acapulco
    City80= hammerfest, city id = 779683, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hammerfest
    City81= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City82= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City83= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City84= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City85= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City86= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City87= severo-kurilsk, city id = 2121385, temp = 28.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=severo-kurilsk
    City88= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City89= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City91= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City92= provideniya, city id = 4031574, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=provideniya
    City93= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City94= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City95= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City96= rehoboth, city id = 3353540, temp = 60.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rehoboth
    City97= saskylakh, city id = 2017155, temp = 6.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saskylakh
    City98= cidreira, city id = 3466165, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cidreira
    City99= provideniya, city id = 4031574, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=provideniya
    City100= bredasdorp, city id = 1015776, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City101= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City102= sur, city id = 286245, temp = 80.16F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sur
    City103= saskylakh, city id = 2017155, temp = 6.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saskylakh
    City104= belmonte, city id = 8010472, temp = 48.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=belmonte
    City105= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City106= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City107= nador, city id = 2541479, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nador
    City108= inhambane, city id = 1045114, temp = 73.23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=inhambane
    City110= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City111= pangnirtung, city id = 6096551, temp = 31.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pangnirtung
    City112= itarema, city id = 3393692, temp = 79.89F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=itarema
    City113= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City114= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City115= guerrero negro, city id = 4021858, temp = 67.74F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=guerrero negro
    City116= nikolskoye, city id = 546105, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nikolskoye
    City117= takoradi, city id = 2294915, temp = 80.12F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=takoradi
    City119= kailua, city id = 5847486, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kailua
    City121= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City122= amalfi, city id = 3690010, temp = 70.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=amalfi
    City123= lebu, city id = 344979, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lebu
    City124= kodiak, city id = 4407665, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kodiak
    City125= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City126= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City127= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City128= mehamn, city id = 778707, temp = 14.15F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mehamn
    City129= zalantun, city id = 2033225, temp = 37.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zalantun
    City130= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City131= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City132= pringsewu, city id = 1630639, temp = 73.1F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pringsewu
    City133= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City134= havelock, city id = 4470244, temp = 68F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=havelock
    City135= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City136= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City137= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City138= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City139= lavrentiya, city id = 4031637, temp = 28.23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lavrentiya
    City140= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City141= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City142= severo-kurilsk, city id = 2121385, temp = 28.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=severo-kurilsk
    City143= gombong, city id = 1649595, temp = 73.64F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=gombong
    City144= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City145= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City146= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City147= bonavista, city id = 5905393, temp = 33.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bonavista
    City148= peniche, city id = 2264923, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=peniche
    City149= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City150= guerrero negro, city id = 4021858, temp = 67.74F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=guerrero negro
    City151= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City152= victor harbor, city id = 2059470, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=victor harbor
    City153= baykit, city id = 1510689, temp = 3.75F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=baykit
    City154= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City156= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City157= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City158= san patricio, city id = 3437029, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san patricio
    City159= hwange, city id = 889942, temp = 58.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hwange
    City160= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City161= wawa, city id = 2319078, temp = 75.89F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=wawa
    City162= constitucion, city id = 4011743, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=constitucion
    City163= sitka, city id = 4267710, temp = 45.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sitka
    City164= sinnamary, city id = 3380290, temp = 77.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sinnamary
    City165= gigmoto, city id = 1712961, temp = 77.28F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=gigmoto
    City166= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City167= iqaluit, city id = 5983720, temp = 5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=iqaluit
    City168= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City170= ancud, city id = 3899695, temp = 54.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ancud
    City171= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City172= tommot, city id = 2015179, temp = 11.9F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tommot
    City173= sur, city id = 286245, temp = 80.16F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sur
    City174= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City175= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City176= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City177= hithadhoo, city id = 1282256, temp = 85.56F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hithadhoo
    City178= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City180= sao joao da barra, city id = 3448903, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sao joao da barra
    City181= ribeira grande, city id = 3372707, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ribeira grande
    City182= akcakoca, city id = 752584, temp = 53.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=akcakoca
    City183= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City184= tshela, city id = 2311127, temp = 74.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tshela
    City186= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City187= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City188= marabba, city id = 370510, temp = 73.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=marabba
    City189= arraial do cabo, city id = 3471451, temp = 78.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arraial do cabo
    City190= shumskiy, city id = 1491977, temp = 15.36F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=shumskiy
    City191= norman wells, city id = 6089245, temp = 24.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=norman wells
    City192= belaya gora, city id = 2126785, temp = 0.74F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=belaya gora
    City193= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City194= inongo, city id = 2315417, temp = 73.1F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=inongo
    City195= nikolskoye, city id = 546105, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nikolskoye
    City196= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City197= khandbari, city id = 1283217, temp = 31.38F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khandbari
    City198= kaeo, city id = 2189343, temp = 71.39F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kaeo
    City199= los llanos de aridane, city id = 2514651, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=los llanos de aridane
    City200= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City201= vostok, city id = 2013279, temp = 45.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vostok
    City202= meulaboh, city id = 1214488, temp = 77.91F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=meulaboh
    City203= sao filipe, city id = 3374210, temp = 70.98F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sao filipe
    City204= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City205= salinopolis, city id = 3389822, temp = 78.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=salinopolis
    City206= pevek, city id = 2122090, temp = 25.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pevek
    City207= cheremukhovo, city id = 466423, temp = 25.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cheremukhovo
    City208= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City209= liku, city id = 1633034, temp = 81.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=liku
    City210= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City211= oyotun, city id = 3694197, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=oyotun
    City212= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City213= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City214= tazovskiy, city id = 1489853, temp = -11.01F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tazovskiy
    City215= dalianwan, city id = 1921372, temp = 42.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dalianwan
    City216= cascais, city id = 2269594, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cascais
    City217= sao filipe, city id = 3374210, temp = 70.98F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sao filipe
    City219= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City221= cape coast, city id = 2302357, temp = 76.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape coast
    City222= saldanha, city id = 2737599, temp = 53.3F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saldanha
    City223= clyde river, city id = 5924351, temp = 6.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=clyde river
    City224= dubai, city id = 292223, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dubai
    City225= kodiak, city id = 4407665, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kodiak
    City226= itoman, city id = 1861280, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=itoman
    City228= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City229= ancud, city id = 3899695, temp = 54.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ancud
    City230= dikson, city id = 1507390, temp = 6.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dikson
    City231= sorland, city id = 3137469, temp = 35.16F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sorland
    City232= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City233= port blair, city id = 1259385, temp = 82.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port blair
    City234= torbay, city id = 6167817, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=torbay
    City236= saint george, city id = 262462, temp = 48.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint george
    City237= codrington, city id = 2160063, temp = 68.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=codrington
    City238= nikolskoye, city id = 546105, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nikolskoye
    City239= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City240= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City243= beringovskiy, city id = 2126710, temp = 32.55F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=beringovskiy
    City244= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City245= aanekoski, city id = 662095, temp = 19.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aanekoski
    City247= feijo, city id = 3658195, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=feijo
    City248= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City249= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City250= kamaishi, city id = 2112444, temp = 44.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kamaishi
    City251= yarmouth, city id = 2633414, temp = 39.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yarmouth
    City252= praia, city id = 3460954, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=praia
    City253= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City254= imeni poliny osipenko, city id = 2023584, temp = 29.49F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=imeni poliny osipenko
    City255= sayyan, city id = 70979, temp = 53.61F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sayyan
    City256= vardo, city id = 4372777, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vardo
    City257= peace river, city id = 6100069, temp = 19.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=peace river
    City258= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City259= souillac, city id = 3026644, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=souillac
    City260= arraial do cabo, city id = 3471451, temp = 78.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arraial do cabo
    City261= padrauna, city id = 1260909, temp = 64.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=padrauna
    City262= alofi, city id = 4036284, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=alofi
    City263= torbay, city id = 6167817, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=torbay
    City265= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City266= henties bay, city id = 3356832, temp = 63.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=henties bay
    City267= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City268= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City269= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City270= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City271= carnarvon, city id = 1014034, temp = 54.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carnarvon
    City273= arraial do cabo, city id = 3471451, temp = 78.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arraial do cabo
    City274= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City275= dudinka, city id = 1507116, temp = -7.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dudinka
    City276= imperial, city id = 5359052, temp = 91.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=imperial
    City277= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City278= makakilo city, city id = 5850554, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=makakilo city
    City279= naryan-mar, city id = 523392, temp = -2.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=naryan-mar
    City280= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City281= egvekinot, city id = 4031742, temp = 29.31F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=egvekinot
    City282= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City283= black river, city id = 3491355, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=black river
    City284= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City285= iqaluit, city id = 5983720, temp = 5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=iqaluit
    City286= melfi, city id = 3173615, temp = 36.69F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=melfi
    City287= prince george, city id = 6113365, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=prince george
    City288= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City289= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City290= flinders, city id = 6255012, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=flinders
    City291= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City292= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City293= upernavik, city id = 3418910, temp = 20.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=upernavik
    City294= glasgow, city id = 2648579, temp = 37.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=glasgow
    City295= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City296= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City297= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City298= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City299= kodiak, city id = 4407665, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kodiak
    City301= nova vicosa, city id = 3456102, temp = 75.66F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nova vicosa
    City302= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City303= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City304= hoyanger, city id = 3151574, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hoyanger
    City305= lebu, city id = 344979, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lebu
    City306= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City307= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City308= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City309= chapais, city id = 5919850, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chapais
    City310= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City311= san quintin, city id = 1688687, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san quintin
    City312= saskylakh, city id = 2017155, temp = 6.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saskylakh
    City313= poum, city id = 787487, temp = 31.38F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=poum
    City314= bailieborough, city id = 2966796, temp = 39.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bailieborough
    City315= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City316= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City317= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City318= hithadhoo, city id = 1282256, temp = 85.56F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hithadhoo
    City319= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City320= minab, city id = 123941, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=minab
    City321= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City322= petropavlovsk-kamchatskiy, city id = 2122104, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=petropavlovsk-kamchatskiy
    City323= klyuchi, city id = 1503153, temp = 6.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=klyuchi
    City324= marsh harbour, city id = 3571913, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=marsh harbour
    City325= aklavik, city id = 5882953, temp = 15.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aklavik
    City326= petropavlovsk-kamchatskiy, city id = 2122104, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=petropavlovsk-kamchatskiy
    City327= ilulissat, city id = 3423146, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ilulissat
    City328= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City329= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City330= airai, city id = 1651810, temp = 76.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=airai
    City331= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City333= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City334= san mateo del mar, city id = 3518382, temp = 85.97F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san mateo del mar
    City335= kremenki, city id = 569360, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kremenki
    City336= ciudad bolivar, city id = 3645532, temp = 89.16F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ciudad bolivar
    City337= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City338= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City339= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City341= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City342= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City343= katsuura, city id = 1865309, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=katsuura
    City344= sri aman, city id = 1735799, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sri aman
    City345= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City346= hami, city id = 1529484, temp = 49.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hami
    City347= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City349= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City350= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City351= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City352= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City353= camocim, city id = 3403687, temp = 78.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=camocim
    City354= moose factory, city id = 6078372, temp = 21.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=moose factory
    City355= kalmunai, city id = 1242110, temp = 70.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kalmunai
    City356= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City357= faya, city id = 110690, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faya
    City358= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City359= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City360= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City361= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City362= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City363= geraldton, city id = 5960603, temp = 19.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=geraldton
    City364= djenne, city id = 2458589, temp = 76.74F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=djenne
    City366= keningau, city id = 1734098, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=keningau
    City368= marrakesh, city id = 2542997, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=marrakesh
    City369= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City370= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City372= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City373= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City374= chirkey, city id = 568077, temp = 44.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chirkey
    City375= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City376= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City377= mahebourg, city id = 934322, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mahebourg
    City378= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City379= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City380= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City381= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City382= havelock, city id = 4470244, temp = 68F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=havelock
    City383= saldanha, city id = 2737599, temp = 53.3F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saldanha
    City384= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City385= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City386= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City387= xining, city id = 1788852, temp = 23.69F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=xining
    City389= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City391= lorengau, city id = 2092164, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lorengau
    City393= buala, city id = 2109528, temp = 85.52F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=buala
    City395= bredasdorp, city id = 1015776, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City396= victoria, city id = 1733782, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=victoria
    City397= manzhouli, city id = 2035836, temp = 21.93F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=manzhouli
    City398= faya, city id = 110690, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faya
    City399= port augusta, city id = 2063056, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port augusta
    City400= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City401= jalu, city id = 86049, temp = 61.67F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jalu
    City402= tulun, city id = 2014927, temp = 14.73F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tulun
    City403= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City404= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City405= srednekolymsk, city id = 2121025, temp = 26.34F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=srednekolymsk
    City407= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City410= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City411= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City412= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City414= coahuayana, city id = 3981460, temp = 86.69F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=coahuayana
    City415= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City416= esperance, city id = 3573739, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=esperance
    City417= manggar, city id = 1636426, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=manggar
    City418= ziarat, city id = 1162094, temp = 39.3F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ziarat
    City419= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City420= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City421= cockburn town, city id = 3576994, temp = 74.85F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cockburn town
    City422= brae, city id = 2654970, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=brae
    City423= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City424= avera, city id = 4231997, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avera
    City425= nikolskoye, city id = 546105, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nikolskoye
    City426= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City427= zhigansk, city id = 2012530, temp = 13.34F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zhigansk
    City428= chuy, city id = 3443061, temp = 69.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chuy
    City429= san felipe, city id = 3872255, temp = 68F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san felipe
    City430= katsuura, city id = 1865309, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=katsuura
    City432= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City433= port hardy, city id = 6111862, temp = 39.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port hardy
    City434= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City435= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City436= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City437= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City438= arraial do cabo, city id = 3471451, temp = 78.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arraial do cabo
    City439= cotui, city id = 3509207, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cotui
    City441= padang, city id = 1633419, temp = 80.39F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=padang
    City442= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City443= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City444= cabedelo, city id = 3404558, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cabedelo
    City445= carnarvon, city id = 1014034, temp = 54.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carnarvon
    City446= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City447= tilichiki, city id = 2120591, temp = 33.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tilichiki
    City448= callaway, city id = 5024237, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=callaway
    City449= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City450= sao filipe, city id = 3374210, temp = 70.98F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sao filipe
    City452= clyde river, city id = 5924351, temp = 6.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=clyde river
    City453= carnarvon, city id = 1014034, temp = 54.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carnarvon
    City454= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City455= camocim, city id = 3403687, temp = 78.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=camocim
    City456= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City457= port hardy, city id = 6111862, temp = 39.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port hardy
    City458= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City459= bredasdorp, city id = 1015776, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City460= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City461= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City462= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City463= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City464= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City465= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City466= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City467= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City469= zhezkazgan, city id = 1516589, temp = 12.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zhezkazgan
    City470= klaksvik, city id = 2618795, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=klaksvik
    City471= shimoda, city id = 1852357, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=shimoda
    City472= balotra, city id = 1277527, temp = 69.77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=balotra
    City473= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City474= airai, city id = 1651810, temp = 76.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=airai
    City475= hollins, city id = 4764534, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hollins
    City476= monze, city id = 906044, temp = 60.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=monze
    City477= moramanga, city id = 1058532, temp = 61.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=moramanga
    City478= shingu, city id = 1847947, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=shingu
    City479= longyearbyen, city id = 2729907, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=longyearbyen
    City480= kraslava, city id = 458623, temp = 39.3F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kraslava
    City481= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City482= amga, city id = 2027786, temp = 23.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=amga
    City483= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City484= saint-denis, city id = 2980916, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-denis
    City485= pemberton, city id = 2063604, temp = 55.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pemberton
    City486= grand-santi, city id = 3381538, temp = 72.87F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=grand-santi
    City487= anito, city id = 1730622, temp = 80.7F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=anito
    City488= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City489= sao filipe, city id = 3374210, temp = 70.98F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sao filipe
    City490= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City491= manado, city id = 1636544, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=manado
    City492= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City493= lompoc, city id = 5367788, temp = 69.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lompoc
    City494= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City495= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City496= puerto asis, city id = 3671549, temp = 78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto asis
    City497= pevek, city id = 2122090, temp = 25.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pevek
    City498= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City499= ribeira grande, city id = 3372707, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ribeira grande
    City500= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City503= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City504= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City509= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City510= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City512= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City513= cayenne, city id = 3382160, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cayenne
    City514= tiarei, city id = 4033356, temp = 89.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiarei
    City515= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City516= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City517= cabo san lucas, city id = 3985710, temp = 74.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cabo san lucas
    City518= bathsheba, city id = 3374083, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bathsheba
    City519= longyearbyen, city id = 2729907, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=longyearbyen
    City520= cidreira, city id = 3466165, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cidreira
    City521= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City522= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City523= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City524= jatiroto, city id = 1643920, temp = 80.75F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jatiroto
    City525= arona, city id = 3182812, temp = 50F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arona
    City526= port augusta, city id = 2063056, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port augusta
    City527= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City528= buala, city id = 2109528, temp = 85.52F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=buala
    City529= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City530= enterprise, city id = 5503766, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=enterprise
    City531= hay river, city id = 5972762, temp = 15.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hay river
    City532= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City533= khatanga, city id = 2022572, temp = -7.86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khatanga
    City534= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City535= chuy, city id = 3443061, temp = 69.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chuy
    City536= port blair, city id = 1259385, temp = 82.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port blair
    City537= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City538= puerto quijarro, city id = 3465342, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto quijarro
    City539= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City540= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City541= margate, city id = 2158744, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=margate
    City542= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City543= emerald, city id = 2167426, temp = 77.69F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=emerald
    City544= khatanga, city id = 2022572, temp = -7.86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khatanga
    City546= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City547= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City548= barranca, city id = 3946820, temp = 69.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barranca
    City549= vawkavysk, city id = 620391, temp = 46.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vawkavysk
    City550= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City551= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City552= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City554= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City555= arraial do cabo, city id = 3471451, temp = 78.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arraial do cabo
    City556= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City557= longyearbyen, city id = 2729907, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=longyearbyen
    City558= qandala, city id = 53157, temp = 69.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qandala
    City559= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City560= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City561= fortuna, city id = 2517679, temp = 53.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fortuna
    City562= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City563= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City564= kieta, city id = 2094027, temp = 83.76F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kieta
    City565= margate, city id = 2158744, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=margate
    City566= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City567= mundo nuevo, city id = 3888214, temp = 53.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mundo nuevo
    City569= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City570= bambous virieux, city id = 1106677, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bambous virieux
    City571= upernavik, city id = 3418910, temp = 20.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=upernavik
    City572= gasa, city id = 1252578, temp = 3.21F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=gasa
    City573= nanortalik, city id = 3421765, temp = 34.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nanortalik
    City574= mana, city id = 789988, temp = 44.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mana
    City575= coahuayana, city id = 3981460, temp = 86.69F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=coahuayana
    City576= lebu, city id = 344979, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lebu
    City577= tawau, city id = 1734199, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tawau
    City578= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City579= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City580= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City581= abdanan, city id = 145233, temp = 46.32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=abdanan
    City582= severo-kurilsk, city id = 2121385, temp = 28.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=severo-kurilsk
    City583= severo-kurilsk, city id = 2121385, temp = 28.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=severo-kurilsk
    City584= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City585= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City587= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City588= omboue, city id = 2396853, temp = 76.97F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=omboue
    City589= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City590= layton, city id = 5777107, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=layton
    City591= plainview, city id = 5528450, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=plainview
    City592= margate, city id = 2158744, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=margate
    City593= teguise, city id = 2510573, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=teguise
    City594= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City595= magdalena, city id = 3915491, temp = 76.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=magdalena
    City596= new norfolk, city id = 2155415, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=new norfolk
    City597= sungaipenuh, city id = 1625929, temp = 63.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sungaipenuh
    City598= beringovskiy, city id = 2126710, temp = 32.55F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=beringovskiy
    City599= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City600= sioux lookout, city id = 6148373, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sioux lookout
    City601= bud, city id = 7626370, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bud
    City602= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City603= bredasdorp, city id = 1015776, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City604= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City605= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City606= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City607= ceahlau, city id = 682483, temp = 34.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ceahlau
    City608= kalmunai, city id = 1242110, temp = 70.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kalmunai
    City609= rabaul, city id = 2087894, temp = 81.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rabaul
    City610= tairua, city id = 2182010, temp = 70.49F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tairua
    City611= padang, city id = 1633419, temp = 80.39F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=padang
    City612= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City613= vanimo, city id = 2084442, temp = 78.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vanimo
    City615= lata, city id = 1253628, temp = 43.62F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lata
    City616= moron, city id = 3631878, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=moron
    City617= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City618= south yuba city, city id = 5397851, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=south yuba city
    City619= flin flon, city id = 5954718, temp = 6.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=flin flon
    City620= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City621= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City622= hambantota, city id = 1244926, temp = 81.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hambantota
    City623= byron bay, city id = 2172880, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=byron bay
    City624= aklavik, city id = 5882953, temp = 15.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aklavik
    City625= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City626= tambacounda, city id = 2244991, temp = 91.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tambacounda
    City627= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City628= los llanos de aridane, city id = 2514651, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=los llanos de aridane
    City629= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City630= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City631= abu zabad, city id = 380348, temp = 68.37F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=abu zabad
    City633= mandapeta, city id = 1263898, temp = 73.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mandapeta
    City634= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City635= vila franca do campo, city id = 3372472, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vila franca do campo
    City636= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City637= assiniboia, city id = 5887798, temp = 15.81F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=assiniboia
    City638= gondal, city id = 1270994, temp = 63.29F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=gondal
    City639= gedo, city id = 337083, temp = 55.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=gedo
    City640= guadalupe y calvo, city id = 4005370, temp = 68.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=guadalupe y calvo
    City642= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City643= buin, city id = 3897774, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=buin
    City644= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City645= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City646= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City647= vila velha, city id = 6320062, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vila velha
    City649= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City650= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City651= ribeira grande, city id = 3372707, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ribeira grande
    City652= college, city id = 5859699, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=college
    City653= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City654= torbay, city id = 6167817, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=torbay
    City655= upernavik, city id = 3418910, temp = 20.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=upernavik
    City656= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City657= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City658= arraial do cabo, city id = 3471451, temp = 78.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arraial do cabo
    City659= pierre, city id = 5767918, temp = 42.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pierre
    City660= vagur, city id = 2610806, temp = 38.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vagur
    City662= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City663= geraldton, city id = 5960603, temp = 19.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=geraldton
    City665= clyde river, city id = 5924351, temp = 6.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=clyde river
    City666= belem de sao francisco, city id = 3405852, temp = 75.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=belem de sao francisco
    City667= kahului, city id = 5847411, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kahului
    City668= lipin bor, city id = 535113, temp = 25.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lipin bor
    City669= homer, city id = 5864145, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=homer
    City670= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City671= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City672= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City673= yeppoon, city id = 2142316, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yeppoon
    City674= vao, city id = 588365, temp = 33.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vao
    City675= nouakchott, city id = 2377450, temp = 66.89F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nouakchott
    City676= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City677= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City678= lompoc, city id = 5367788, temp = 69.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lompoc
    City679= aksha, city id = 2028028, temp = 15.36F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aksha
    City680= mokhsogollokh, city id = 2019867, temp = 16.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mokhsogollokh
    City681= montego bay, city id = 3489460, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=montego bay
    City682= vaitape, city id = 4033077, temp = 83.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaitape
    City683= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City684= camacha, city id = 2270385, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=camacha
    City685= port blair, city id = 1259385, temp = 82.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port blair
    City686= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City687= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City688= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City689= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City690= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City691= kapit, city id = 1737185, temp = 73.77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapit
    City692= omboue, city id = 2396853, temp = 76.97F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=omboue
    City693= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City694= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City695= sarangani, city id = 1687186, temp = 82.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sarangani
    City696= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City697= bubaque, city id = 2374583, temp = 76.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bubaque
    City698= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City699= christchurch, city id = 2192362, temp = 68F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=christchurch
    City700= roros, city id = 3141332, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=roros
    City701= lake charles, city id = 4330236, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lake charles
    City702= upernavik, city id = 3418910, temp = 20.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=upernavik
    City703= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City704= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City705= sabang, city id = 1691355, temp = 76.11F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sabang
    City706= yulara, city id = 6355222, temp = 86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yulara
    City707= hofn, city id = 2630299, temp = 30.21F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hofn
    City708= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City709= bredasdorp, city id = 1015776, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City710= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City711= conway, city id = 4575461, temp = 68F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=conway
    City712= te anau, city id = 2181625, temp = 61.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=te anau
    City713= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City714= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City715= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City716= bilibino, city id = 2126682, temp = 33.77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bilibino
    City717= nuuk, city id = 3421319, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nuuk
    City718= ponta delgada, city id = 3372783, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta delgada
    City719= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City720= hambantota, city id = 1244926, temp = 81.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hambantota
    City721= khatanga, city id = 2022572, temp = -7.86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khatanga
    City722= pisco, city id = 3932145, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pisco
    City723= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City725= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City726= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City727= fallon, city id = 5681948, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fallon
    City728= rocha, city id = 3440777, temp = 66.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rocha
    City729= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City730= yelatma, city id = 468030, temp = 35.16F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yelatma
    City731= sinaloa, city id = 4011469, temp = 91.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sinaloa
    City732= fairbanks, city id = 5861897, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fairbanks
    City733= willowmore, city id = 939676, temp = 54.87F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=willowmore
    City734= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City735= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City737= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City739= hofn, city id = 2630299, temp = 30.21F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hofn
    City740= comodoro rivadavia, city id = 3860443, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=comodoro rivadavia
    City741= hasaki, city id = 2112802, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hasaki
    City742= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City743= bhadasar, city id = 1276355, temp = 70.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bhadasar
    City744= chuy, city id = 3443061, temp = 69.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chuy
    City745= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City746= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City747= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City748= masingbi, city id = 2403846, temp = 70.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=masingbi
    City749= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City750= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City751= sarangani, city id = 1687186, temp = 82.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sarangani
    City752= sechura, city id = 3691954, temp = 75.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sechura
    City753= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City754= vostok, city id = 2013279, temp = 45.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vostok
    City755= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City756= san andres, city id = 1690438, temp = 78.99F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san andres
    City757= okato, city id = 2185763, temp = 64.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=okato
    City758= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City759= saskylakh, city id = 2017155, temp = 6.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saskylakh
    City760= lexington park, city id = 4360592, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lexington park
    City761= mehamn, city id = 778707, temp = 14.15F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mehamn
    City763= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City764= tual, city id = 1623197, temp = 80.43F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tual
    City765= tawau, city id = 1734199, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tawau
    City766= aleppo, city id = 170063, temp = 48.93F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aleppo
    City767= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City768= beringovskiy, city id = 2126710, temp = 32.55F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=beringovskiy
    City769= kyle, city id = 4703811, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kyle
    City770= victoria, city id = 1733782, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=victoria
    City771= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City772= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City773= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City775= husavik, city id = 5961417, temp = 23.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=husavik
    City776= provideniya, city id = 4031574, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=provideniya
    City777= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City778= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City779= beloha, city id = 1067565, temp = 74.9F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=beloha
    City781= anshun, city id = 1817968, temp = 56.85F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=anshun
    City782= lebu, city id = 344979, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lebu
    City783= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City784= esperance, city id = 3573739, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=esperance
    City785= coihueco, city id = 3894406, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=coihueco
    City786= west fargo, city id = 5062458, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=west fargo
    City787= vyshestebliyevskaya, city id = 797083, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vyshestebliyevskaya
    City788= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City789= erenhot, city id = 2037485, temp = 42.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=erenhot
    City790= dosso, city id = 2445488, temp = 78.32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dosso
    City791= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City792= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City793= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City794= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City796= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City797= youkounkoun, city id = 2414055, temp = 82.55F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=youkounkoun
    City798= qaqortoq, city id = 3420846, temp = 41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaqortoq
    City800= lamesa, city id = 5524849, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lamesa
    City801= tura, city id = 1254046, temp = 60.77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tura
    City802= dikson, city id = 1507390, temp = 6.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dikson
    City803= mocajuba, city id = 3394745, temp = 77.91F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mocajuba
    City804= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City805= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City806= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City807= sonoita, city id = 5313135, temp = 86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sonoita
    City808= manzhouli, city id = 2035836, temp = 21.93F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=manzhouli
    City809= kavieng, city id = 2094342, temp = 85.65F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kavieng
    City810= arraial do cabo, city id = 3471451, temp = 78.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arraial do cabo
    City813= fort nelson, city id = 5955902, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fort nelson
    City814= cockburn town, city id = 3576994, temp = 74.85F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cockburn town
    City815= meulaboh, city id = 1214488, temp = 77.91F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=meulaboh
    City816= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City817= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City818= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City819= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City820= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City821= half moon bay, city id = 5354943, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=half moon bay
    City822= upernavik, city id = 3418910, temp = 20.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=upernavik
    City823= dikson, city id = 1507390, temp = 6.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dikson
    City824= snasa, city id = 3138076, temp = 16.89F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=snasa
    City825= san juan, city id = 3837213, temp = 58.52F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san juan
    City827= kodiak, city id = 4407665, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kodiak
    City828= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City829= isangel, city id = 2136825, temp = 81.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=isangel
    City830= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City831= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City832= esperance, city id = 3573739, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=esperance
    City833= kodiak, city id = 4407665, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kodiak
    City834= hualmay, city id = 3939761, temp = 69.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hualmay
    City835= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City836= ribeira grande, city id = 3372707, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ribeira grande
    City837= cururupu, city id = 3401148, temp = 77.87F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cururupu
    City838= vila franca do campo, city id = 3372472, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vila franca do campo
    City839= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City841= carhuamayo, city id = 3945466, temp = 45.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carhuamayo
    City842= mehamn, city id = 778707, temp = 14.15F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mehamn
    City843= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City844= zhigalovo, city id = 2012532, temp = 13.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zhigalovo
    City845= proti, city id = 736229, temp = 36.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=proti
    City846= chuy, city id = 3443061, temp = 69.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chuy
    City847= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City848= norman wells, city id = 6089245, temp = 24.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=norman wells
    City849= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City850= kawalu, city id = 1640902, temp = 66.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kawalu
    City851= collie, city id = 2074113, temp = 55.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=collie
    City852= zabol, city id = 1113217, temp = 53.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zabol
    City853= kruisfontein, city id = 986717, temp = 64.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kruisfontein
    City856= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City859= eureka, city id = 5563397, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=eureka
    City860= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City861= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City862= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City863= salalah, city id = 286621, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=salalah
    City864= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City865= palmer, city id = 2067070, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=palmer
    City866= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City867= jumla, city id = 1283285, temp = 19.55F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jumla
    City868= san quintin, city id = 1688687, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san quintin
    City870= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City871= husavik, city id = 5961417, temp = 23.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=husavik
    City872= atar, city id = 2381334, temp = 63.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atar
    City873= nanortalik, city id = 3421765, temp = 34.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nanortalik
    City874= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City875= poum, city id = 787487, temp = 31.38F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=poum
    City876= ust-nera, city id = 2120048, temp = 10.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ust-nera
    City877= new norfolk, city id = 2155415, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=new norfolk
    City878= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City879= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City880= blagoevgrad, city id = 733191, temp = 33.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=blagoevgrad
    City881= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City882= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City883= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City884= samarai, city id = 2132606, temp = 85.29F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=samarai
    City885= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City886= bubaque, city id = 2374583, temp = 76.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bubaque
    City887= luganville, city id = 2136150, temp = 79.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=luganville
    City888= wenling, city id = 1791464, temp = 65.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=wenling
    City889= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City890= ketchikan, city id = 5554428, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ketchikan
    City891= gat, city id = 2249901, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=gat
    City892= pevek, city id = 2122090, temp = 25.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pevek
    City893= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City894= tuatapere, city id = 2180815, temp = 66.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuatapere
    City895= boa vista, city id = 3664980, temp = 89.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=boa vista
    City896= flinders, city id = 6255012, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=flinders
    City897= verkhnyaya inta, city id = 1487332, temp = 7.04F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=verkhnyaya inta
    City898= sibu, city id = 1735902, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sibu
    City899= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City900= ancud, city id = 3899695, temp = 54.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ancud
    City901= antofagasta, city id = 3899539, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=antofagasta
    City902= ust-nera, city id = 2120048, temp = 10.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ust-nera
    City903= rabaul, city id = 2087894, temp = 81.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rabaul
    City904= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City905= bograd, city id = 1509847, temp = 17.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bograd
    City906= kaitangata, city id = 2208248, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kaitangata
    City907= merauke, city id = 2082539, temp = 80.43F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=merauke
    City908= pochutla, city id = 3517970, temp = 86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pochutla
    City909= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City910= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City911= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City912= yekaterinoslavka, city id = 1532612, temp = 21.21F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yekaterinoslavka
    City914= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City915= carnarvon, city id = 1014034, temp = 54.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carnarvon
    City916= lebu, city id = 344979, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lebu
    City917= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City918= berlevag, city id = 780687, temp = 17.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=berlevag
    City919= kontagora, city id = 2334008, temp = 74.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kontagora
    City920= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City921= segezha, city id = 497927, temp = 13.7F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=segezha
    City922= saskylakh, city id = 2017155, temp = 6.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saskylakh
    City923= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City924= la ronge, city id = 6050066, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=la ronge
    City925= nikolskoye, city id = 546105, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nikolskoye
    City926= sisimiut, city id = 3419842, temp = 15.81F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sisimiut
    City927= geraldton, city id = 5960603, temp = 19.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=geraldton
    City928= magadan, city id = 2123628, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=magadan
    City929= souillac, city id = 3026644, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=souillac
    City930= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City931= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City932= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City933= trabzon, city id = 738648, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=trabzon
    City934= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City935= peniche, city id = 2264923, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=peniche
    City936= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City937= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City939= sandy bay, city id = 2206089, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sandy bay
    City940= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City942= chhindwara, city id = 1274304, temp = 58.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chhindwara
    City943= lompoc, city id = 5367788, temp = 69.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lompoc
    City944= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City946= alofi, city id = 4036284, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=alofi
    City947= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City949= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City950= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City951= dikson, city id = 1507390, temp = 6.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dikson
    City952= genhe, city id = 2037252, temp = 19.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=genhe
    City953= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City954= ibicui, city id = 3461602, temp = 70.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ibicui
    City955= kropotkin, city id = 540761, temp = 44.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kropotkin
    City956= lompoc, city id = 5367788, temp = 69.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lompoc
    City957= bondowoso, city id = 1648266, temp = 76.83F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bondowoso
    City958= mahebourg, city id = 934322, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mahebourg
    City959= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City960= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City961= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City962= aksarka, city id = 1512019, temp = -11.55F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aksarka
    City963= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City964= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City965= dingle, city id = 1714733, temp = 75.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dingle
    City966= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City967= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City968= tuatapere, city id = 2180815, temp = 66.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuatapere
    City969= kaitangata, city id = 2208248, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kaitangata
    City972= santa isabel, city id = 3668716, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=santa isabel
    City973= hirado, city id = 1862555, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hirado
    City974= cabo san lucas, city id = 3985710, temp = 74.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cabo san lucas
    City976= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City977= puerto leguizamo, city id = 3671437, temp = 79.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto leguizamo
    City978= half moon bay, city id = 5354943, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=half moon bay
    City979= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City981= salta, city id = 3838233, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=salta
    City982= mahebourg, city id = 934322, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mahebourg
    City983= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City984= cabanbanan, city id = 1711719, temp = 76.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cabanbanan
    City985= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City986= batagay-alyta, city id = 2027042, temp = 7.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=batagay-alyta
    City987= dubna, city id = 564719, temp = 37.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dubna
    City988= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City989= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City990= nanortalik, city id = 3421765, temp = 34.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nanortalik
    City991= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City992= neuquen, city id = 3843123, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=neuquen
    City993= klaksvik, city id = 2618795, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=klaksvik
    City994= sorland, city id = 3137469, temp = 35.16F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sorland
    City995= port hedland, city id = 2063042, temp = 86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port hedland
    City996= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City997= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City999= guanambi, city id = 3461973, temp = 73.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=guanambi
    City1000= dunhua, city id = 2037534, temp = 56.04F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dunhua
    City1001= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1002= mentougou, city id = 1800657, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mentougou
    City1003= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1004= bredasdorp, city id = 1015776, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City1005= catuday, city id = 1717787, temp = 77.73F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=catuday
    City1006= port blair, city id = 1259385, temp = 82.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port blair
    City1007= umea, city id = 602150, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=umea
    City1009= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City1010= aykhal, city id = 2027296, temp = 2.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aykhal
    City1011= malangali, city id = 155052, temp = 62.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=malangali
    City1013= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1014= brae, city id = 2654970, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=brae
    City1015= severo-kurilsk, city id = 2121385, temp = 28.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=severo-kurilsk
    City1016= oussouye, city id = 2246901, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=oussouye
    City1017= imbituba, city id = 3461370, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=imbituba
    City1018= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City1020= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1021= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1022= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1023= kearney, city id = 5071348, temp = 28.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kearney
    City1024= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1025= flinders, city id = 6255012, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=flinders
    City1026= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1027= bredasdorp, city id = 1015776, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City1028= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City1029= kruisfontein, city id = 986717, temp = 64.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kruisfontein
    City1030= lebu, city id = 344979, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lebu
    City1031= pokhara, city id = 1282898, temp = 51.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pokhara
    City1032= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1034= ust-ilimsk, city id = 2013952, temp = 14.64F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ust-ilimsk
    City1035= porbandar, city id = 1259395, temp = 70.53F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=porbandar
    City1036= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City1038= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City1039= garissa, city id = 197745, temp = 76.65F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=garissa
    City1040= turukhansk, city id = 1488903, temp = 1.23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=turukhansk
    City1041= pangnirtung, city id = 6096551, temp = 31.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pangnirtung
    City1042= wote, city id = 178077, temp = 64.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=wote
    City1043= codrington, city id = 2160063, temp = 68.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=codrington
    City1044= viedma, city id = 3832899, temp = 61.53F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=viedma
    City1045= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1046= mahebourg, city id = 934322, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mahebourg
    City1047= kungurtug, city id = 1501377, temp = 1.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kungurtug
    City1048= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1049= tezu, city id = 1254709, temp = 58.38F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tezu
    City1050= dauphin, city id = 5935341, temp = 17.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dauphin
    City1051= fort nelson, city id = 5955902, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fort nelson
    City1052= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1053= bambous virieux, city id = 1106677, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bambous virieux
    City1055= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1056= srednekolymsk, city id = 2121025, temp = 26.34F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=srednekolymsk
    City1059= leningradskiy, city id = 2123814, temp = 26.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=leningradskiy
    City1060= srednyaya yelyuzan, city id = 489393, temp = 34.67F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=srednyaya yelyuzan
    City1061= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City1062= siirt, city id = 300822, temp = 41.46F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=siirt
    City1063= coquimbo, city id = 3893629, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=coquimbo
    City1065= buenos aires, city id = 3435910, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=buenos aires
    City1066= zhanaozen, city id = 607610, temp = 33.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zhanaozen
    City1067= yayva, city id = 468560, temp = 14.28F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yayva
    City1068= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City1069= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City1070= san cristobal, city id = 3652462, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san cristobal
    City1072= port hedland, city id = 2063042, temp = 86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port hedland
    City1073= cayenne, city id = 3382160, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cayenne
    City1074= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1075= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City1076= luau, city id = 876177, temp = 61.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=luau
    City1077= marquette, city id = 5000947, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=marquette
    City1078= narsaq, city id = 3421719, temp = 41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=narsaq
    City1080= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1081= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City1082= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1083= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1084= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City1085= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1086= torbay, city id = 6167817, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=torbay
    City1087= north platte, city id = 5697939, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=north platte
    City1088= vokhtoga, city id = 472878, temp = 22.79F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vokhtoga
    City1089= abu zabad, city id = 380348, temp = 68.37F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=abu zabad
    City1090= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City1091= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1093= curaca, city id = 3401331, temp = 81.51F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=curaca
    City1094= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1095= ahipara, city id = 2194098, temp = 69.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ahipara
    City1097= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City1098= mongo, city id = 240498, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mongo
    City1099= bridlington, city id = 2654728, temp = 39.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bridlington
    City1100= skibbereen, city id = 2961459, temp = 37.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=skibbereen
    City1101= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City1102= nome, city id = 4732862, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nome
    City1103= blagoveshchensk, city id = 2026609, temp = 41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=blagoveshchensk
    City1104= guerrero negro, city id = 4021858, temp = 67.74F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=guerrero negro
    City1107= provideniya, city id = 4031574, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=provideniya
    City1108= ribeira grande, city id = 3372707, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ribeira grande
    City1109= salalah, city id = 286621, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=salalah
    City1111= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1112= new norfolk, city id = 2155415, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=new norfolk
    City1113= new norfolk, city id = 2155415, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=new norfolk
    City1114= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1115= saint-augustin, city id = 3031582, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-augustin
    City1116= san jose, city id = 1689431, temp = 70.85F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san jose
    City1117= caravelas, city id = 3466980, temp = 80.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=caravelas
    City1118= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City1119= khatanga, city id = 2022572, temp = -7.86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khatanga
    City1120= taveta, city id = 179525, temp = 67.65F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=taveta
    City1121= chicama, city id = 3698359, temp = 68F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chicama
    City1122= alofi, city id = 4036284, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=alofi
    City1123= dogondoutchi, city id = 2445553, temp = 74.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dogondoutchi
    City1124= vallenar, city id = 3868633, temp = 59.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vallenar
    City1125= vung tau, city id = 1562414, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vung tau
    City1126= messina, city id = 2524170, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=messina
    City1127= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1128= saskylakh, city id = 2017155, temp = 6.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saskylakh
    City1129= san ramon, city id = 3616584, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san ramon
    City1130= cidreira, city id = 3466165, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cidreira
    City1131= mahebourg, city id = 934322, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mahebourg
    City1132= hithadhoo, city id = 1282256, temp = 85.56F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hithadhoo
    City1133= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1134= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City1135= san luis, city id = 3837056, temp = 68.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san luis
    City1136= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1137= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1138= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1139= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1142= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City1143= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1144= russell, city id = 3844421, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=russell
    City1145= northam, city id = 2641434, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=northam
    City1146= praya, city id = 1630662, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=praya
    City1147= husavik, city id = 5961417, temp = 23.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=husavik
    City1148= talnakh, city id = 1490256, temp = -10.56F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=talnakh
    City1149= amuntai, city id = 1651461, temp = 77.46F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=amuntai
    City1150= kavieng, city id = 2094342, temp = 85.65F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kavieng
    City1151= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City1152= seoul, city id = 1835848, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=seoul
    City1153= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1154= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1156= buala, city id = 2109528, temp = 85.52F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=buala
    City1157= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City1159= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1160= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City1161= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1162= nioro, city id = 2413070, temp = 80.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nioro
    City1163= mareeba, city id = 2158767, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mareeba
    City1164= taltal, city id = 3870243, temp = 59.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=taltal
    City1165= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1166= chany, city id = 1508458, temp = 15.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chany
    City1167= vieste, city id = 3164387, temp = 51.99F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vieste
    City1168= batagay-alyta, city id = 2027042, temp = 7.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=batagay-alyta
    City1169= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1170= souillac, city id = 3026644, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=souillac
    City1171= casablanca, city id = 2553604, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=casablanca
    City1172= rawson, city id = 3839307, temp = 70.98F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rawson
    City1173= curuca, city id = 3663145, temp = 79.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=curuca
    City1175= ayan, city id = 749747, temp = 47.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ayan
    City1176= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City1177= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1178= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1179= pangkalanbuun, city id = 1632694, temp = 77.46F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pangkalanbuun
    City1180= port hawkesbury, city id = 6111867, temp = 42.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port hawkesbury
    City1181= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City1182= cherskiy, city id = 2126199, temp = 29.31F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cherskiy
    City1183= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1184= hamilton, city id = 3573197, temp = 68F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hamilton
    City1185= zahnitkiv, city id = 618453, temp = 42.14F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zahnitkiv
    City1186= rosario, city id = 3440747, temp = 67.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rosario
    City1187= kaitangata, city id = 2208248, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kaitangata
    City1188= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1189= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1190= hofn, city id = 2630299, temp = 30.21F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hofn
    City1191= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1192= saldanha, city id = 2737599, temp = 53.3F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saldanha
    City1193= touros, city id = 3386213, temp = 80.61F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=touros
    City1194= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1195= chuy, city id = 3443061, temp = 69.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chuy
    City1196= haines junction, city id = 5969025, temp = 20.9F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=haines junction
    City1197= arman, city id = 2127060, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arman
    City1198= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City1199= pandan, city id = 1695555, temp = 81.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pandan
    City1201= erdenet, city id = 2031405, temp = 15.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=erdenet
    City1202= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1203= villa guerrero, city id = 3980172, temp = 79.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=villa guerrero
    City1204= dingle, city id = 1714733, temp = 75.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dingle
    City1205= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1206= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1207= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1208= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1209= paracuru, city id = 3393115, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=paracuru
    City1210= caluquembe, city id = 3351024, temp = 61.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=caluquembe
    City1211= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1212= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1213= bredasdorp, city id = 1015776, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City1214= naze, city id = 2337542, temp = 75.66F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=naze
    City1215= nikolskoye, city id = 546105, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nikolskoye
    City1216= thompson, city id = 6165406, temp = -0.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=thompson
    City1217= muli, city id = 1256929, temp = 67.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=muli
    City1218= airai, city id = 1651810, temp = 76.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=airai
    City1219= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City1220= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1221= padang, city id = 1633419, temp = 80.39F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=padang
    City1222= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1223= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City1225= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1226= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City1227= lazaro cardenas, city id = 3996234, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lazaro cardenas
    City1228= dunmore town, city id = 3572462, temp = 72.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dunmore town
    City1229= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1230= camalu, city id = 3979216, temp = 67.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=camalu
    City1231= dwarka, city id = 1273294, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dwarka
    City1232= fortuna, city id = 2517679, temp = 53.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fortuna
    City1233= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1234= tilichiki, city id = 2120591, temp = 33.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tilichiki
    City1235= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1236= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1237= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1238= komsomolskiy, city id = 1486910, temp = -10.29F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=komsomolskiy
    City1239= brae, city id = 2654970, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=brae
    City1241= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1242= lagoa, city id = 2267254, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lagoa
    City1243= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1244= alofi, city id = 4036284, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=alofi
    City1245= dolores, city id = 3435038, temp = 64.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dolores
    City1246= las choapas, city id = 3524903, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=las choapas
    City1247= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City1248= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1249= alofi, city id = 4036284, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=alofi
    City1250= banda aceh, city id = 1215502, temp = 72.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=banda aceh
    City1251= longyearbyen, city id = 2729907, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=longyearbyen
    City1254= bandarbeyla, city id = 64814, temp = 80.79F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bandarbeyla
    City1255= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1256= tottori, city id = 1849892, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tottori
    City1257= banepa, city id = 1283679, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=banepa
    City1258= mangrol, city id = 1263751, temp = 65.13F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mangrol
    City1259= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1260= nuuk, city id = 3421319, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nuuk
    City1262= fortuna, city id = 2517679, temp = 53.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fortuna
    City1263= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City1264= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1265= khatanga, city id = 2022572, temp = -7.86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khatanga
    City1266= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City1267= russellville, city id = 4129397, temp = 50.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=russellville
    City1269= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1270= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1271= arraial do cabo, city id = 3471451, temp = 78.59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=arraial do cabo
    City1272= poum, city id = 787487, temp = 31.38F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=poum
    City1274= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City1275= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1277= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1278= mankono, city id = 2284589, temp = 77.73F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mankono
    City1279= khatanga, city id = 2022572, temp = -7.86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khatanga
    City1280= oskarshamn, city id = 2686162, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=oskarshamn
    City1281= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1284= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1285= lagoa, city id = 2267254, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lagoa
    City1287= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City1288= norman wells, city id = 6089245, temp = 24.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=norman wells
    City1290= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City1291= leningradskiy, city id = 2123814, temp = 26.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=leningradskiy
    City1292= tilichiki, city id = 2120591, temp = 33.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tilichiki
    City1293= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1294= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1295= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1296= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City1297= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City1298= wanaka, city id = 2184707, temp = 59.64F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=wanaka
    City1299= hukuntsi, city id = 933726, temp = 63.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hukuntsi
    City1300= cherskiy, city id = 2126199, temp = 29.31F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cherskiy
    City1301= khani, city id = 610864, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khani
    City1302= cherskiy, city id = 2126199, temp = 29.31F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cherskiy
    City1303= bintulu, city id = 1737486, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bintulu
    City1304= baykit, city id = 1510689, temp = 3.75F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=baykit
    City1305= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City1307= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1312= nikolskoye, city id = 546105, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nikolskoye
    City1313= los llanos de aridane, city id = 2514651, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=los llanos de aridane
    City1314= geraldton, city id = 5960603, temp = 19.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=geraldton
    City1315= broken hill, city id = 2173911, temp = 72.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=broken hill
    City1317= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1318= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City1319= kavaratti, city id = 1267390, temp = 83.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kavaratti
    City1320= itarema, city id = 3393692, temp = 79.89F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=itarema
    City1321= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1322= jacqueville, city id = 2290582, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jacqueville
    City1323= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1324= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1325= riyadh, city id = 108410, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=riyadh
    City1326= thompson, city id = 6165406, temp = -0.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=thompson
    City1327= geraldton, city id = 5960603, temp = 19.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=geraldton
    City1328= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City1329= walvis bay, city id = 3359638, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=walvis bay
    City1330= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1331= khandyga, city id = 2022773, temp = 20.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khandyga
    City1332= kodiak, city id = 4407665, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kodiak
    City1333= volokolamsk, city id = 472433, temp = 36.69F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=volokolamsk
    City1334= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City1335= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1336= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1338= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City1339= vardo, city id = 4372777, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vardo
    City1341= satipo, city id = 3928924, temp = 66.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=satipo
    City1342= clyde river, city id = 5924351, temp = 6.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=clyde river
    City1344= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City1345= laguna, city id = 4013704, temp = 86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=laguna
    City1346= komsomolskiy, city id = 1486910, temp = -10.29F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=komsomolskiy
    City1347= del rio, city id = 5520076, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=del rio
    City1348= morehead, city id = 4301307, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=morehead
    City1349= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City1350= puchezh, city id = 504294, temp = 27.51F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puchezh
    City1352= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1353= taseyevo, city id = 1490058, temp = 19.23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=taseyevo
    City1355= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1356= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City1357= fort morgan, city id = 5577158, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fort morgan
    City1358= ancud, city id = 3899695, temp = 54.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ancud
    City1359= thompson, city id = 6165406, temp = -0.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=thompson
    City1360= havoysund, city id = 779622, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=havoysund
    City1361= kodiak, city id = 4407665, temp = 26.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kodiak
    City1362= khatanga, city id = 2022572, temp = -7.86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khatanga
    City1363= amahai, city id = 1651591, temp = 82.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=amahai
    City1365= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City1366= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City1367= jaleswar, city id = 1269413, temp = 75.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jaleswar
    City1368= new norfolk, city id = 2155415, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=new norfolk
    City1369= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City1370= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1372= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1373= vao, city id = 588365, temp = 33.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vao
    City1374= new norfolk, city id = 2155415, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=new norfolk
    City1375= santa marta, city id = 3668605, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=santa marta
    City1376= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1377= bredasdorp, city id = 1015776, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bredasdorp
    City1378= honningsvag, city id = 779554, temp = 20.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=honningsvag
    City1379= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1380= makakilo city, city id = 5850554, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=makakilo city
    City1381= shasta lake, city id = 5571109, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=shasta lake
    City1382= coquimbo, city id = 3893629, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=coquimbo
    City1383= totness, city id = 4589590, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=totness
    City1384= san patricio, city id = 3437029, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san patricio
    City1385= grootfontein, city id = 3357114, temp = 57.48F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=grootfontein
    City1386= okhotsk, city id = 2122605, temp = 28.1F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=okhotsk
    City1387= nikolskoye, city id = 546105, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nikolskoye
    City1388= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City1389= lebu, city id = 344979, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lebu
    City1391= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City1392= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City1393= ouadda, city id = 236901, temp = 74.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ouadda
    City1395= hofn, city id = 2630299, temp = 30.21F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hofn
    City1396= carnarvon, city id = 1014034, temp = 54.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carnarvon
    City1397= saint george, city id = 262462, temp = 47.49F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint george
    City1398= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1399= ranot, city id = 1607068, temp = 75.93F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ranot
    City1400= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1401= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City1402= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City1403= klaksvik, city id = 2618795, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=klaksvik
    City1405= kitale, city id = 191220, temp = 50.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kitale
    City1406= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1407= basco, city id = 4863349, temp = 24.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=basco
    City1408= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1409= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City1410= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1411= enkoping, city id = 2716166, temp = 32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=enkoping
    City1412= henties bay, city id = 3356832, temp = 63.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=henties bay
    City1413= torbay, city id = 6167817, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=torbay
    City1414= lindi, city id = 878281, temp = 73.1F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lindi
    City1415= victoria, city id = 1733782, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=victoria
    City1416= torbay, city id = 6167817, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=torbay
    City1420= kavaratti, city id = 1267390, temp = 83.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kavaratti
    City1421= shunyi, city id = 2034754, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=shunyi
    City1423= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1424= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City1425= ilulissat, city id = 3423146, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ilulissat
    City1426= angouleme, city id = 3037598, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=angouleme
    City1427= san ramon de la nueva oran, city id = 3836620, temp = 67.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san ramon de la nueva oran
    City1428= naze, city id = 2337542, temp = 75.66F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=naze
    City1429= ahuimanu, city id = 5856516, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ahuimanu
    City1430= souillac, city id = 3026644, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=souillac
    City1431= pevek, city id = 2122090, temp = 25.44F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pevek
    City1433= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City1434= san quintin, city id = 1688687, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san quintin
    City1435= mataram, city id = 1630639, temp = 73.1F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataram
    City1436= wageningen, city id = 2745088, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=wageningen
    City1437= telfs, city id = 2763810, temp = 39.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=telfs
    City1438= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City1439= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City1440= hithadhoo, city id = 1282256, temp = 85.56F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hithadhoo
    City1441= leningradskiy, city id = 2123814, temp = 26.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=leningradskiy
    City1442= qaanaaq, city id = 3831208, temp = 9.92F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=qaanaaq
    City1443= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City1446= ustyuzhna, city id = 477795, temp = 29.58F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ustyuzhna
    City1447= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1448= ancud, city id = 3899695, temp = 54.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ancud
    City1449= kita, city id = 1850144, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kita
    City1450= saint-pierre, city id = 2995603, temp = 39.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-pierre
    City1451= birao, city id = 240210, temp = 71.34F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=birao
    City1452= ambilobe, city id = 1082243, temp = 69.77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ambilobe
    City1453= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City1455= mar del plata, city id = 3863379, temp = 62.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mar del plata
    City1456= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1457= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City1458= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City1459= torbay, city id = 6167817, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=torbay
    City1460= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1461= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City1462= longyearbyen, city id = 2729907, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=longyearbyen
    City1463= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1464= necochea, city id = 3430443, temp = 56.85F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=necochea
    City1465= mitrofanovka, city id = 700019, temp = 47.76F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mitrofanovka
    City1466= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1468= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1469= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City1470= port augusta, city id = 2063056, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port augusta
    City1471= lagoa, city id = 2267254, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lagoa
    City1474= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City1475= adre, city id = 245669, temp = 68.01F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=adre
    City1476= marawi, city id = 1701054, temp = 75.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=marawi
    City1477= chingirlau, city id = 610091, temp = 22.38F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chingirlau
    City1478= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1479= coquimbo, city id = 3893629, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=coquimbo
    City1480= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1481= aykhal, city id = 2027296, temp = 2.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aykhal
    City1482= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City1483= zhuhai, city id = 2052479, temp = 53.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zhuhai
    City1484= hithadhoo, city id = 1282256, temp = 85.56F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hithadhoo
    City1486= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1487= paducah, city id = 4048662, temp = 41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=paducah
    City1489= saldanha, city id = 2737599, temp = 53.3F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saldanha
    City1490= provideniya, city id = 4031574, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=provideniya
    City1491= puerto rico, city id = 3429732, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto rico
    City1492= surgut, city id = 1490624, temp = 15.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=surgut
    City1493= lavrentiya, city id = 4031637, temp = 28.23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lavrentiya
    City1494= severo-kurilsk, city id = 2121385, temp = 28.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=severo-kurilsk
    City1495= chokurdakh, city id = 2126123, temp = -3.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chokurdakh
    City1496= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1497= college, city id = 5859699, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=college
    City1498= bocaiuva, city id = 3469601, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bocaiuva
    City1499= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City1500= paamiut, city id = 3421193, temp = 34.85F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=paamiut
    City1501= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City1503= bluff, city id = 2175403, temp = 78.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bluff
    City1504= lavrentiya, city id = 4031637, temp = 28.23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lavrentiya
    City1505= hithadhoo, city id = 1282256, temp = 85.56F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hithadhoo
    City1506= pangai, city id = 4032369, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pangai
    City1507= codrington, city id = 2160063, temp = 68.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=codrington
    City1508= vostok, city id = 2013279, temp = 45.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vostok
    City1509= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1510= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1511= ilulissat, city id = 3423146, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ilulissat
    City1512= hasaki, city id = 2112802, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hasaki
    City1513= souillac, city id = 3026644, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=souillac
    City1514= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1515= hasaki, city id = 2112802, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hasaki
    City1516= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1517= saint-augustin, city id = 3031582, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-augustin
    City1518= makinsk, city id = 1521230, temp = 17.34F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=makinsk
    City1519= geraldton, city id = 5960603, temp = 19.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=geraldton
    City1520= chegdomyn, city id = 2025579, temp = 37.77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chegdomyn
    City1521= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1522= selfoss, city id = 3413604, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=selfoss
    City1523= galesong, city id = 1644605, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=galesong
    City1524= charters towers, city id = 2171722, temp = 74.67F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=charters towers
    City1525= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City1526= krasnoarmeysk, city id = 542463, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=krasnoarmeysk
    City1527= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1528= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1529= dikson, city id = 1507390, temp = 6.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dikson
    City1530= alice springs, city id = 2077895, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=alice springs
    City1531= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1532= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1533= poum, city id = 787487, temp = 31.38F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=poum
    City1534= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1535= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City1536= octeville, city id = 2989755, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=octeville
    City1537= gazli, city id = 1513990, temp = 45.74F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=gazli
    City1538= dingle, city id = 1714733, temp = 75.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dingle
    City1540= half moon bay, city id = 5354943, temp = 75.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=half moon bay
    City1541= ilulissat, city id = 3423146, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ilulissat
    City1543= provideniya, city id = 4031574, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=provideniya
    City1544= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City1545= berlevag, city id = 780687, temp = 17.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=berlevag
    City1546= lingyuan, city id = 2036075, temp = 60.36F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lingyuan
    City1547= lebu, city id = 344979, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lebu
    City1549= nome, city id = 4732862, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nome
    City1550= new norfolk, city id = 2155415, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=new norfolk
    City1551= klaksvik, city id = 2618795, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=klaksvik
    City1553= morehead, city id = 4301307, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=morehead
    City1554= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1555= gambela, city id = 337405, temp = 59.37F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=gambela
    City1556= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City1557= codrington, city id = 2160063, temp = 68.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=codrington
    City1559= zhezkazgan, city id = 1516589, temp = 12.57F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=zhezkazgan
    City1560= fortuna, city id = 2517679, temp = 53.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fortuna
    City1561= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1562= videira, city id = 3445126, temp = 65.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=videira
    City1563= mahebourg, city id = 934322, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mahebourg
    City1564= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1565= weligama, city id = 1223738, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=weligama
    City1566= dogondoutchi, city id = 2445553, temp = 74.54F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dogondoutchi
    City1567= san cristobal, city id = 3652462, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san cristobal
    City1568= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City1570= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1571= luwuk, city id = 1637001, temp = 75.75F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=luwuk
    City1573= harper, city id = 4696310, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=harper
    City1574= dhankuta, city id = 1283465, temp = 56.72F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dhankuta
    City1575= castro, city id = 3896218, temp = 52.26F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=castro
    City1576= marawi, city id = 1701054, temp = 75.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=marawi
    City1577= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1578= kaitangata, city id = 2208248, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kaitangata
    City1580= dikson, city id = 1507390, temp = 6.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dikson
    City1581= jega, city id = 2336237, temp = 77.1F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jega
    City1582= carnarvon, city id = 1014034, temp = 54.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=carnarvon
    City1583= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City1584= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1585= cehegin, city id = 2519651, temp = 39.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cehegin
    City1586= avenal, city id = 5325327, temp = 84.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avenal
    City1587= thompson, city id = 6165406, temp = -0.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=thompson
    City1588= butaritari, city id = 2110227, temp = 83.94F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=butaritari
    City1589= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1590= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City1591= kudahuvadhoo, city id = 1337607, temp = 85.65F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kudahuvadhoo
    City1592= kununurra, city id = 2068110, temp = 87.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kununurra
    City1593= muroran, city id = 2129101, temp = 42.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=muroran
    City1594= upernavik, city id = 3418910, temp = 20.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=upernavik
    City1595= papara, city id = 3395473, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=papara
    City1597= port alfred, city id = 964432, temp = 72.06F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port alfred
    City1598= burnie, city id = 2173125, temp = 61.08F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=burnie
    City1599= sur, city id = 286245, temp = 80.16F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sur
    City1600= bulawayo, city id = 894701, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bulawayo
    City1601= provideniya, city id = 4031574, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=provideniya
    City1602= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1603= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1606= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1607= airai, city id = 1651810, temp = 76.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=airai
    City1608= lavrentiya, city id = 4031637, temp = 28.23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lavrentiya
    City1610= avarua, city id = 4035715, temp = 82.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=avarua
    City1611= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City1613= cockburn town, city id = 3576994, temp = 74.85F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cockburn town
    City1614= saint george, city id = 262462, temp = 47.49F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint george
    City1615= esso, city id = 2125711, temp = 20.13F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=esso
    City1618= bubaque, city id = 2374583, temp = 76.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bubaque
    City1620= balakovo, city id = 579492, temp = 28.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=balakovo
    City1621= ancud, city id = 3899695, temp = 54.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ancud
    City1622= port blair, city id = 1259385, temp = 82.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port blair
    City1623= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1624= katsuura, city id = 1865309, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=katsuura
    City1625= sarakhs, city id = 1159716, temp = 48.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sarakhs
    City1627= ayagoz, city id = 1525988, temp = 11.99F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ayagoz
    City1628= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1629= issoudun, city id = 3012655, temp = 42.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=issoudun
    City1630= wenatchee, city id = 5815342, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=wenatchee
    City1631= lasa, city id = 146639, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lasa
    City1632= cabo san lucas, city id = 3985710, temp = 74.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cabo san lucas
    City1633= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1634= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City1635= dikson, city id = 1507390, temp = 6.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dikson
    City1636= inhambane, city id = 1045114, temp = 73.23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=inhambane
    City1637= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City1638= nouadhibou, city id = 2377457, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nouadhibou
    City1639= saint-philippe, city id = 6138908, temp = 33.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-philippe
    City1640= kizema, city id = 547871, temp = 3.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kizema
    City1641= atuona, city id = 4020109, temp = 81.78F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atuona
    City1642= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1643= souillac, city id = 3026644, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=souillac
    City1644= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1645= san cristobal, city id = 3652462, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san cristobal
    City1646= belmonte, city id = 8010472, temp = 48.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=belmonte
    City1647= jinxiang, city id = 1787335, temp = 66.39F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jinxiang
    City1648= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City1649= lagoa, city id = 2267254, temp = 57.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lagoa
    City1650= new norfolk, city id = 2155415, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=new norfolk
    City1651= maragogi, city id = 3395458, temp = 75.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=maragogi
    City1652= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1653= aksu, city id = 1524298, temp = 17.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=aksu
    City1654= dikson, city id = 1507390, temp = 6.63F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=dikson
    City1655= ipixuna, city id = 3408424, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ipixuna
    City1656= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City1657= severo-kurilsk, city id = 2121385, temp = 28.5F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=severo-kurilsk
    City1658= mecca, city id = 104515, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mecca
    City1659= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1660= mitsamiouli, city id = 921786, temp = 80.79F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mitsamiouli
    City1662= bubaque, city id = 2374583, temp = 76.47F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bubaque
    City1663= hithadhoo, city id = 1282256, temp = 85.56F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hithadhoo
    City1664= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1665= kenai, city id = 5866063, temp = 44.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kenai
    City1666= nanakuli, city id = 5851349, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nanakuli
    City1667= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1668= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1669= salym, city id = 1493162, temp = 18.87F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=salym
    City1670= souillac, city id = 3026644, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=souillac
    City1672= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City1673= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1675= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1676= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City1677= jamestown, city id = 2069194, temp = 63.02F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=jamestown
    City1678= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1679= kungurtug, city id = 1501377, temp = 1.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kungurtug
    City1680= codrington, city id = 2160063, temp = 68.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=codrington
    City1681= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1683= faya, city id = 110690, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faya
    City1684= nemuro, city id = 2128975, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nemuro
    City1685= pisco, city id = 3932145, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pisco
    City1686= menongue, city id = 3347353, temp = 59.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=menongue
    City1688= rennes, city id = 2983990, temp = 48.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rennes
    City1689= bethel, city id = 5880568, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=bethel
    City1690= kutum, city id = 371745, temp = 60.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kutum
    City1691= norman wells, city id = 6089245, temp = 24.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=norman wells
    City1692= busselton, city id = 2075265, temp = 60.27F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=busselton
    City1695= kariya, city id = 1860034, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kariya
    City1696= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1697= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1698= airai, city id = 1651810, temp = 76.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=airai
    City1699= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City1700= tromso, city id = 3133895, temp = 30.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tromso
    City1701= nishihara, city id = 1850144, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nishihara
    City1703= cape town, city id = 3369157, temp = 64.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=cape town
    City1704= iracoubo, city id = 3381428, temp = 77.87F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=iracoubo
    City1705= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1707= punta arenas, city id = 3874787, temp = 51.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=punta arenas
    City1709= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City1710= kruisfontein, city id = 986717, temp = 64.82F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kruisfontein
    City1711= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1712= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1713= namibe, city id = 3347019, temp = 79.62F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=namibe
    City1715= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City1716= san cristobal, city id = 3652462, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=san cristobal
    City1717= kavieng, city id = 2094342, temp = 85.65F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kavieng
    City1718= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City1719= kropotkin, city id = 540761, temp = 44.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kropotkin
    City1720= port elizabeth, city id = 4501427, temp = 59F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port elizabeth
    City1721= santa fe, city id = 3836277, temp = 73.55F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=santa fe
    City1722= hilo, city id = 5855927, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hilo
    City1724= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City1726= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1727= caucasia, city id = 3687025, temp = 75.89F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=caucasia
    City1729= faanui, city id = 4034551, temp = 82.19F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=faanui
    City1730= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City1731= kargil, city id = 1267776, temp = -3.36F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kargil
    City1732= yaring, city id = 1604771, temp = 75.03F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yaring
    City1733= yellowknife, city id = 6185377, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yellowknife
    City1734= ponta do sol, city id = 3453439, temp = 69.09F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ponta do sol
    City1735= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1736= sao filipe, city id = 3374210, temp = 70.98F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sao filipe
    City1737= tuktoyaktuk, city id = 6170031, temp = 10.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tuktoyaktuk
    City1738= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1739= upernavik, city id = 3418910, temp = 20.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=upernavik
    City1740= husavik, city id = 5961417, temp = 23.24F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=husavik
    City1742= sao joao da barra, city id = 3448903, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=sao joao da barra
    City1743= hobart, city id = 2163355, temp = 66.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hobart
    City1744= saint-francois, city id = 2980080, temp = 37.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=saint-francois
    City1745= tasiilaq, city id = 3424607, temp = 23F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tasiilaq
    City1746= isangel, city id = 2136825, temp = 81.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=isangel
    City1747= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1748= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City1749= shiyan, city id = 1794903, temp = 59.42F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=shiyan
    City1750= nemuro, city id = 2128975, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=nemuro
    City1751= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1752= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1753= tiksi, city id = 2015306, temp = 0.96F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=tiksi
    City1754= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City1755= yulara, city id = 6355222, temp = 86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=yulara
    City1756= moron, city id = 3631878, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=moron
    City1758= kapaa, city id = 5848280, temp = 78.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=kapaa
    City1759= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1760= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1761= lasa, city id = 146639, temp = 55.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=lasa
    City1762= atambua, city id = 1651103, temp = 80.79F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=atambua
    City1763= santa rosa, city id = 3835994, temp = 62.43F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=santa rosa
    City1767= luderitz, city id = 3355672, temp = 62.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=luderitz
    City1768= chapais, city id = 5919850, temp = 12.2F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=chapais
    City1769= mataura, city id = 6201424, temp = 69.45F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=mataura
    City1770= barrow, city id = 3833859, temp = 57.17F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=barrow
    City1771= iskateley, city id = 866062, temp = -7.32F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=iskateley
    City1772= thompson, city id = 6165406, temp = -0.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=thompson
    City1773= fortuna, city id = 2517679, temp = 53.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=fortuna
    City1774= rong kwang, city id = 1606983, temp = 67.79F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rong kwang
    City1775= necochea, city id = 3430443, temp = 56.85F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=necochea
    City1776= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    City1777= ouango, city id = 236844, temp = 73.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ouango
    City1778= georgetown, city id = 3378644, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=georgetown
    City1780= port keats, city id = 2063039, temp = 89.25F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=port keats
    City1781= pisco, city id = 3932145, temp = 71.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=pisco
    City1782= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1783= puerto ayora, city id = 3652764, temp = 77F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=puerto ayora
    City1784= hualmay, city id = 3939761, temp = 69.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hualmay
    City1785= manjacaze, city id = 1040938, temp = 69.99F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=manjacaze
    City1786= seoul, city id = 1835848, temp = 60.8F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=seoul
    City1787= hermanus, city id = 3366880, temp = 55.95F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=hermanus
    City1788= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1789= novikovo, city id = 712587, temp = 46.05F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=novikovo
    City1790= khatanga, city id = 2022572, temp = -7.86F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=khatanga
    City1791= vaini, city id = 1273574, temp = 64.41F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=vaini
    City1793= acapulco, city id = 3533462, temp = 80.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=acapulco
    City1794= albany, city id = 5106834, temp = 35.6F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=albany
    City1795= ribeira grande, city id = 3372707, temp = 63.33F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ribeira grande
    City1797= ushuaia, city id = 3833367, temp = 46.4F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=ushuaia
    City1798= caravelas, city id = 3466980, temp = 80.84F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=caravelas
    City1799= rikitea, city id = 4030556, temp = 79.22F, url =http://api.openweathermap.org/data/2.5/weather?appid=api_key&q=rikitea
    


```python
worldcityweather = pd.DataFrame(mylist)
worldcityweather.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>city_id</th>
      <th>cloudiness</th>
      <th>humidity</th>
      <th>lat</th>
      <th>lon</th>
      <th>temp</th>
      <th>windspeed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>pevek</td>
      <td>2122090</td>
      <td>0</td>
      <td>82</td>
      <td>69.70</td>
      <td>170.27</td>
      <td>25.44</td>
      <td>11.54</td>
    </tr>
    <tr>
      <th>1</th>
      <td>tilichiki</td>
      <td>2120591</td>
      <td>88</td>
      <td>90</td>
      <td>60.47</td>
      <td>166.10</td>
      <td>33.05</td>
      <td>16.02</td>
    </tr>
    <tr>
      <th>2</th>
      <td>yuza</td>
      <td>1848016</td>
      <td>40</td>
      <td>87</td>
      <td>39.05</td>
      <td>139.95</td>
      <td>50.00</td>
      <td>8.05</td>
    </tr>
    <tr>
      <th>3</th>
      <td>hermanus</td>
      <td>3366880</td>
      <td>0</td>
      <td>91</td>
      <td>-34.42</td>
      <td>19.24</td>
      <td>55.95</td>
      <td>1.70</td>
    </tr>
    <tr>
      <th>4</th>
      <td>barrow</td>
      <td>3833859</td>
      <td>0</td>
      <td>80</td>
      <td>-38.31</td>
      <td>-60.23</td>
      <td>57.17</td>
      <td>8.41</td>
    </tr>
  </tbody>
</table>
</div>




```python
worldcityweather = worldcityweather.drop_duplicates(subset=["city"], keep="first")
worldcityweather.count()
```




    city          624
    city_id       624
    cloudiness    624
    humidity      624
    lat           624
    lon           624
    temp          624
    windspeed     624
    dtype: int64




```python
worldcityweather.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city_id</th>
      <th>cloudiness</th>
      <th>humidity</th>
      <th>lat</th>
      <th>lon</th>
      <th>temp</th>
      <th>windspeed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>6.240000e+02</td>
      <td>624.000000</td>
      <td>624.000000</td>
      <td>624.000000</td>
      <td>624.000000</td>
      <td>624.000000</td>
      <td>624.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2.667578e+06</td>
      <td>38.064103</td>
      <td>75.506410</td>
      <td>20.720817</td>
      <td>17.640032</td>
      <td>55.604295</td>
      <td>8.132788</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.597080e+06</td>
      <td>35.491446</td>
      <td>21.523736</td>
      <td>32.770500</td>
      <td>90.318645</td>
      <td>24.061238</td>
      <td>5.475424</td>
    </tr>
    <tr>
      <th>min</th>
      <td>5.315700e+04</td>
      <td>0.000000</td>
      <td>7.000000</td>
      <td>-54.810000</td>
      <td>-179.170000</td>
      <td>-11.550000</td>
      <td>0.250000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.528610e+06</td>
      <td>0.000000</td>
      <td>65.000000</td>
      <td>-4.035000</td>
      <td>-61.835000</td>
      <td>36.645000</td>
      <td>3.710000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.200094e+06</td>
      <td>32.000000</td>
      <td>81.000000</td>
      <td>25.510000</td>
      <td>21.475000</td>
      <td>62.600000</td>
      <td>6.930000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>3.646286e+06</td>
      <td>75.000000</td>
      <td>93.000000</td>
      <td>48.057500</td>
      <td>100.415000</td>
      <td>75.682500</td>
      <td>10.980000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>8.010472e+06</td>
      <td>100.000000</td>
      <td>100.000000</td>
      <td>78.220000</td>
      <td>179.320000</td>
      <td>91.400000</td>
      <td>39.060000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#create a scatterplot for Temperature (F) vs. Latitude
my_plot = worldcityweather.plot(kind="scatter", x="lat", y="temp", grid=True, figsize=(20,10), title="City Lattitude vs. Max Temp (4/1/18)")
my_plot.set_xlabel("City Lattitude (degree)", fontsize=28)
my_plot.set_ylabel("City Temperature (F)", fontsize=28)
my_plot.set_title(my_plot.title.get_text(), fontsize=32)
plt.savefig("VWong_City_Lattitude_vs_Temp.png")
plt.show()
```


![png](output_8_0.png)



```python
#create a scatterplot for Humidity(%) vs. Latitude
my_plot = worldcityweather.plot(kind="scatter", x="lat", y="humidity", grid=True, figsize=(20,10), color = "orange", title="City Lattitude vs. Humidity% (4/1/18)")
my_plot.set_xlabel("City Lattitude (degree)", fontsize=28)
my_plot.set_ylabel("City Humidity (%)", fontsize=28)
my_plot.set_title(my_plot.title.get_text(), fontsize=32)
plt.savefig("VWong_City_Lattitude_vs_Humidity.png")
plt.show()
```


![png](output_9_0.png)



```python
#create a scatterplot for Cloudiness(%) vs. Latitude
my_plot = worldcityweather.plot(kind="scatter", x="lat", y="cloudiness", grid=True, figsize=(20,10), color = "purple", title="City Lattitude vs. Cloudiness% (4/1/18)")
my_plot.set_xlabel("City Lattitude (degree)", fontsize=28)
my_plot.set_ylabel("City Cloudiness (%)", fontsize=28)
my_plot.set_title(my_plot.title.get_text(), fontsize=32)
plt.savefig("VWong_City_Lattitude_vs_Cloudiness.png")
plt.show()
```


![png](output_10_0.png)



```python
#create a scatterplot for Wind Speed (mph) vs. Latitude
my_plot = worldcityweather.plot(kind="scatter", x="lat", y="windspeed", grid=True, figsize=(20,10), color = "green", title="City Lattitude vs. Windspeed MPH (4/1/18)")
my_plot.set_xlabel("City Lattitude (degree)", fontsize=28)
my_plot.set_ylabel("City Windspeed (MPH)", fontsize=28)
my_plot.set_title(my_plot.title.get_text(), fontsize=32)
plt.savefig("VWong_City_Lattitude_vs_Windspeed.png")
plt.show()
```


![png](output_11_0.png)



```python
worldcityweather.to_csv('worldcityweather.csv') 
```
