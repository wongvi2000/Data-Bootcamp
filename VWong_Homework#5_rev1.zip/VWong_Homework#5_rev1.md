
Your objective is to build a Bubble Plot that showcases the relationship between four key variables:
•Average Fare ($) Per City
•Total Number of Rides Per City
•Total Number of Drivers Per City
•City Type (Urban, Suburban, Rural)

In addition, you will be expected to produce the following three pie charts:
•% of Total Fares by City Type
•% of Total Rides by City Type
•% of Total Drivers by City Type


```python
# Dependencies
import pandas as pd
import numpy as np
import os
from matplotlib import pyplot as plt
```


```python
# open the two data files and transform them into dataframes
city_file = "raw_data/city_data.csv"
ride_file = "raw_data/ride_data.csv" 


```


```python
city_df = pd.read_csv(city_file)
city_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
ride_df = pd.read_csv(ride_file)
ride_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
# perform an inner join - intersection
merged_cityride_df = pd.merge(city_df, ride_df, on = "city")
merged_cityride_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
  </tbody>
</table>
</div>




```python
merged_cityride_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>driver_count</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>2407.00000</td>
      <td>2407.000000</td>
      <td>2.407000e+03</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>31.14167</td>
      <td>26.867104</td>
      <td>4.856048e+12</td>
    </tr>
    <tr>
      <th>std</th>
      <td>22.05840</td>
      <td>12.007238</td>
      <td>2.898402e+12</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.00000</td>
      <td>4.050000</td>
      <td>2.238753e+09</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>12.00000</td>
      <td>17.320000</td>
      <td>2.354637e+12</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>24.00000</td>
      <td>26.490000</td>
      <td>4.804713e+12</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>51.00000</td>
      <td>36.710000</td>
      <td>7.356325e+12</td>
    </tr>
    <tr>
      <th>max</th>
      <td>73.00000</td>
      <td>59.650000</td>
      <td>9.997901e+12</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Provides you the average fare per city (125 rows), use this for the Y-axis of the bubble chart
groupbycity = merged_cityride_df.groupby(["city", "type"])
groupbycity.mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>driver_count</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>city</th>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <th>Urban</th>
      <td>21.0</td>
      <td>23.928710</td>
      <td>5.351586e+12</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <th>Urban</th>
      <td>67.0</td>
      <td>20.609615</td>
      <td>3.536678e+12</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <th>Suburban</th>
      <td>16.0</td>
      <td>37.315556</td>
      <td>4.195870e+12</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <th>Urban</th>
      <td>21.0</td>
      <td>23.625000</td>
      <td>5.086800e+12</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <th>Urban</th>
      <td>49.0</td>
      <td>21.981579</td>
      <td>4.574788e+12</td>
    </tr>
    <tr>
      <th>Arnoldview</th>
      <th>Urban</th>
      <td>41.0</td>
      <td>25.106452</td>
      <td>5.021952e+12</td>
    </tr>
    <tr>
      <th>Campbellport</th>
      <th>Suburban</th>
      <td>26.0</td>
      <td>33.711333</td>
      <td>5.805424e+12</td>
    </tr>
    <tr>
      <th>Carrollbury</th>
      <th>Suburban</th>
      <td>4.0</td>
      <td>36.606000</td>
      <td>4.274615e+12</td>
    </tr>
    <tr>
      <th>Carrollfort</th>
      <th>Urban</th>
      <td>55.0</td>
      <td>25.395517</td>
      <td>4.759008e+12</td>
    </tr>
    <tr>
      <th>Clarkstad</th>
      <th>Suburban</th>
      <td>21.0</td>
      <td>31.051667</td>
      <td>6.682745e+12</td>
    </tr>
    <tr>
      <th>Conwaymouth</th>
      <th>Suburban</th>
      <td>18.0</td>
      <td>34.591818</td>
      <td>4.391649e+12</td>
    </tr>
    <tr>
      <th>Davidtown</th>
      <th>Urban</th>
      <td>73.0</td>
      <td>22.978095</td>
      <td>5.850005e+12</td>
    </tr>
    <tr>
      <th>Davistown</th>
      <th>Urban</th>
      <td>25.0</td>
      <td>21.497200</td>
      <td>4.361977e+12</td>
    </tr>
    <tr>
      <th>East Cherylfurt</th>
      <th>Suburban</th>
      <td>9.0</td>
      <td>31.416154</td>
      <td>3.981187e+12</td>
    </tr>
    <tr>
      <th>East Douglas</th>
      <th>Urban</th>
      <td>12.0</td>
      <td>26.169091</td>
      <td>4.732315e+12</td>
    </tr>
    <tr>
      <th>East Erin</th>
      <th>Urban</th>
      <td>43.0</td>
      <td>24.478214</td>
      <td>5.226259e+12</td>
    </tr>
    <tr>
      <th>East Jenniferchester</th>
      <th>Suburban</th>
      <td>22.0</td>
      <td>32.599474</td>
      <td>5.933107e+12</td>
    </tr>
    <tr>
      <th>East Leslie</th>
      <th>Rural</th>
      <td>9.0</td>
      <td>33.660909</td>
      <td>6.051052e+12</td>
    </tr>
    <tr>
      <th>East Stephen</th>
      <th>Rural</th>
      <td>6.0</td>
      <td>39.053000</td>
      <td>5.306327e+12</td>
    </tr>
    <tr>
      <th>East Troybury</th>
      <th>Rural</th>
      <td>3.0</td>
      <td>33.244286</td>
      <td>5.948234e+12</td>
    </tr>
    <tr>
      <th>Edwardsbury</th>
      <th>Urban</th>
      <td>11.0</td>
      <td>26.876667</td>
      <td>5.296117e+12</td>
    </tr>
    <tr>
      <th>Erikport</th>
      <th>Rural</th>
      <td>3.0</td>
      <td>30.043750</td>
      <td>6.883015e+12</td>
    </tr>
    <tr>
      <th>Eriktown</th>
      <th>Urban</th>
      <td>15.0</td>
      <td>25.478947</td>
      <td>4.113171e+12</td>
    </tr>
    <tr>
      <th>Floresberg</th>
      <th>Suburban</th>
      <td>7.0</td>
      <td>32.310000</td>
      <td>2.630319e+12</td>
    </tr>
    <tr>
      <th>Fosterside</th>
      <th>Urban</th>
      <td>69.0</td>
      <td>23.034583</td>
      <td>5.101131e+12</td>
    </tr>
    <tr>
      <th>Hernandezshire</th>
      <th>Rural</th>
      <td>10.0</td>
      <td>32.002222</td>
      <td>5.206210e+12</td>
    </tr>
    <tr>
      <th>Horneland</th>
      <th>Rural</th>
      <td>8.0</td>
      <td>21.482500</td>
      <td>5.351789e+12</td>
    </tr>
    <tr>
      <th>Jacksonfort</th>
      <th>Rural</th>
      <td>6.0</td>
      <td>32.006667</td>
      <td>4.610855e+12</td>
    </tr>
    <tr>
      <th>Jacobfort</th>
      <th>Urban</th>
      <td>52.0</td>
      <td>24.779355</td>
      <td>4.099091e+12</td>
    </tr>
    <tr>
      <th>Jasonfort</th>
      <th>Suburban</th>
      <td>25.0</td>
      <td>27.831667</td>
      <td>6.439182e+12</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>South Roy</th>
      <th>Urban</th>
      <td>35.0</td>
      <td>26.031364</td>
      <td>4.862249e+12</td>
    </tr>
    <tr>
      <th>South Shannonborough</th>
      <th>Suburban</th>
      <td>9.0</td>
      <td>26.516667</td>
      <td>4.824875e+12</td>
    </tr>
    <tr>
      <th>Spencertown</th>
      <th>Urban</th>
      <td>68.0</td>
      <td>23.681154</td>
      <td>4.850559e+12</td>
    </tr>
    <tr>
      <th>Stevensport</th>
      <th>Rural</th>
      <td>6.0</td>
      <td>31.948000</td>
      <td>3.125721e+12</td>
    </tr>
    <tr>
      <th>Stewartview</th>
      <th>Urban</th>
      <td>49.0</td>
      <td>21.614000</td>
      <td>4.936695e+12</td>
    </tr>
    <tr>
      <th>Swansonbury</th>
      <th>Urban</th>
      <td>64.0</td>
      <td>27.464706</td>
      <td>4.443028e+12</td>
    </tr>
    <tr>
      <th>Thomastown</th>
      <th>Suburban</th>
      <td>1.0</td>
      <td>30.308333</td>
      <td>4.525633e+12</td>
    </tr>
    <tr>
      <th>Tiffanyton</th>
      <th>Suburban</th>
      <td>21.0</td>
      <td>28.510000</td>
      <td>4.968458e+12</td>
    </tr>
    <tr>
      <th>Torresshire</th>
      <th>Urban</th>
      <td>70.0</td>
      <td>24.207308</td>
      <td>5.117907e+12</td>
    </tr>
    <tr>
      <th>Travisville</th>
      <th>Urban</th>
      <td>37.0</td>
      <td>27.220870</td>
      <td>3.317507e+12</td>
    </tr>
    <tr>
      <th>Vickimouth</th>
      <th>Urban</th>
      <td>13.0</td>
      <td>21.474667</td>
      <td>4.242738e+12</td>
    </tr>
    <tr>
      <th>Webstertown</th>
      <th>Suburban</th>
      <td>26.0</td>
      <td>29.721250</td>
      <td>4.401465e+12</td>
    </tr>
    <tr>
      <th>West Alexis</th>
      <th>Urban</th>
      <td>47.0</td>
      <td>19.523000</td>
      <td>5.133766e+12</td>
    </tr>
    <tr>
      <th>West Brandy</th>
      <th>Urban</th>
      <td>12.0</td>
      <td>24.157667</td>
      <td>4.673435e+12</td>
    </tr>
    <tr>
      <th>West Brittanyton</th>
      <th>Urban</th>
      <td>9.0</td>
      <td>25.436250</td>
      <td>5.796976e+12</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <th>Urban</th>
      <td>34.0</td>
      <td>22.330345</td>
      <td>5.119541e+12</td>
    </tr>
    <tr>
      <th>West Evan</th>
      <th>Suburban</th>
      <td>4.0</td>
      <td>27.013333</td>
      <td>5.445616e+12</td>
    </tr>
    <tr>
      <th>West Jefferyfurt</th>
      <th>Urban</th>
      <td>65.0</td>
      <td>21.072857</td>
      <td>3.614437e+12</td>
    </tr>
    <tr>
      <th>West Kevintown</th>
      <th>Rural</th>
      <td>5.0</td>
      <td>21.528571</td>
      <td>7.002171e+12</td>
    </tr>
    <tr>
      <th>West Oscar</th>
      <th>Urban</th>
      <td>11.0</td>
      <td>24.280000</td>
      <td>4.525743e+12</td>
    </tr>
    <tr>
      <th>West Pamelaborough</th>
      <th>Suburban</th>
      <td>27.0</td>
      <td>33.799286</td>
      <td>4.081521e+12</td>
    </tr>
    <tr>
      <th>West Paulport</th>
      <th>Suburban</th>
      <td>5.0</td>
      <td>33.278235</td>
      <td>4.895520e+12</td>
    </tr>
    <tr>
      <th>West Peter</th>
      <th>Urban</th>
      <td>61.0</td>
      <td>24.875484</td>
      <td>4.630766e+12</td>
    </tr>
    <tr>
      <th>West Sydneyhaven</th>
      <th>Urban</th>
      <td>70.0</td>
      <td>22.368333</td>
      <td>4.432234e+12</td>
    </tr>
    <tr>
      <th>West Tony</th>
      <th>Suburban</th>
      <td>17.0</td>
      <td>29.609474</td>
      <td>5.080147e+12</td>
    </tr>
    <tr>
      <th>Williamchester</th>
      <th>Suburban</th>
      <td>26.0</td>
      <td>34.278182</td>
      <td>5.679295e+12</td>
    </tr>
    <tr>
      <th>Williamshire</th>
      <th>Urban</th>
      <td>70.0</td>
      <td>26.990323</td>
      <td>4.937704e+12</td>
    </tr>
    <tr>
      <th>Wiseborough</th>
      <th>Urban</th>
      <td>55.0</td>
      <td>22.676842</td>
      <td>6.046575e+12</td>
    </tr>
    <tr>
      <th>Yolandafurt</th>
      <th>Urban</th>
      <td>7.0</td>
      <td>27.205500</td>
      <td>4.870867e+12</td>
    </tr>
    <tr>
      <th>Zimmermanmouth</th>
      <th>Urban</th>
      <td>45.0</td>
      <td>28.301667</td>
      <td>4.618734e+12</td>
    </tr>
  </tbody>
</table>
<p>125 rows × 3 columns</p>
</div>




```python
groupbycitynotype = merged_cityride_df.groupby(["city"])
#groupbycitynotype.mean()
```


```python
# Provides you with the total driver count per city, 125 rows - use this for the size of the bubble chart
groupbycity.sum()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>driver_count</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>city</th>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <th>Urban</th>
      <td>651</td>
      <td>741.79</td>
      <td>165899161874789</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <th>Urban</th>
      <td>1742</td>
      <td>535.85</td>
      <td>91953627077845</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <th>Suburban</th>
      <td>144</td>
      <td>335.84</td>
      <td>37762826439863</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <th>Urban</th>
      <td>462</td>
      <td>519.75</td>
      <td>111909606921566</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <th>Urban</th>
      <td>931</td>
      <td>417.65</td>
      <td>86920968698689</td>
    </tr>
    <tr>
      <th>Arnoldview</th>
      <th>Urban</th>
      <td>1271</td>
      <td>778.30</td>
      <td>155680516453154</td>
    </tr>
    <tr>
      <th>Campbellport</th>
      <th>Suburban</th>
      <td>390</td>
      <td>505.67</td>
      <td>87081359966001</td>
    </tr>
    <tr>
      <th>Carrollbury</th>
      <th>Suburban</th>
      <td>40</td>
      <td>366.06</td>
      <td>42746154832213</td>
    </tr>
    <tr>
      <th>Carrollfort</th>
      <th>Urban</th>
      <td>1595</td>
      <td>736.47</td>
      <td>138011218621745</td>
    </tr>
    <tr>
      <th>Clarkstad</th>
      <th>Suburban</th>
      <td>252</td>
      <td>372.62</td>
      <td>80192945283941</td>
    </tr>
    <tr>
      <th>Conwaymouth</th>
      <th>Suburban</th>
      <td>198</td>
      <td>380.51</td>
      <td>48308135196746</td>
    </tr>
    <tr>
      <th>Davidtown</th>
      <th>Urban</th>
      <td>1533</td>
      <td>482.54</td>
      <td>122850096918371</td>
    </tr>
    <tr>
      <th>Davistown</th>
      <th>Urban</th>
      <td>625</td>
      <td>537.43</td>
      <td>109049430394422</td>
    </tr>
    <tr>
      <th>East Cherylfurt</th>
      <th>Suburban</th>
      <td>117</td>
      <td>408.41</td>
      <td>51755429107151</td>
    </tr>
    <tr>
      <th>East Douglas</th>
      <th>Urban</th>
      <td>264</td>
      <td>575.72</td>
      <td>104110928441114</td>
    </tr>
    <tr>
      <th>East Erin</th>
      <th>Urban</th>
      <td>1204</td>
      <td>685.39</td>
      <td>146335263646091</td>
    </tr>
    <tr>
      <th>East Jenniferchester</th>
      <th>Suburban</th>
      <td>418</td>
      <td>619.39</td>
      <td>112729038851138</td>
    </tr>
    <tr>
      <th>East Leslie</th>
      <th>Rural</th>
      <td>99</td>
      <td>370.27</td>
      <td>66561575296093</td>
    </tr>
    <tr>
      <th>East Stephen</th>
      <th>Rural</th>
      <td>60</td>
      <td>390.53</td>
      <td>53063273613807</td>
    </tr>
    <tr>
      <th>East Troybury</th>
      <th>Rural</th>
      <td>21</td>
      <td>232.71</td>
      <td>41637638844907</td>
    </tr>
    <tr>
      <th>Edwardsbury</th>
      <th>Urban</th>
      <td>297</td>
      <td>725.67</td>
      <td>142995149955093</td>
    </tr>
    <tr>
      <th>Erikport</th>
      <th>Rural</th>
      <td>24</td>
      <td>240.35</td>
      <td>55064119128623</td>
    </tr>
    <tr>
      <th>Eriktown</th>
      <th>Urban</th>
      <td>285</td>
      <td>484.10</td>
      <td>78150241601348</td>
    </tr>
    <tr>
      <th>Floresberg</th>
      <th>Suburban</th>
      <td>70</td>
      <td>323.10</td>
      <td>26303190411293</td>
    </tr>
    <tr>
      <th>Fosterside</th>
      <th>Urban</th>
      <td>1656</td>
      <td>552.83</td>
      <td>122427139452426</td>
    </tr>
    <tr>
      <th>Hernandezshire</th>
      <th>Rural</th>
      <td>90</td>
      <td>288.02</td>
      <td>46855891812045</td>
    </tr>
    <tr>
      <th>Horneland</th>
      <th>Rural</th>
      <td>32</td>
      <td>85.93</td>
      <td>21407156167741</td>
    </tr>
    <tr>
      <th>Jacksonfort</th>
      <th>Rural</th>
      <td>36</td>
      <td>192.04</td>
      <td>27665127138520</td>
    </tr>
    <tr>
      <th>Jacobfort</th>
      <th>Urban</th>
      <td>1612</td>
      <td>768.16</td>
      <td>127071827580827</td>
    </tr>
    <tr>
      <th>Jasonfort</th>
      <th>Suburban</th>
      <td>300</td>
      <td>333.98</td>
      <td>77270188680128</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>South Roy</th>
      <th>Urban</th>
      <td>770</td>
      <td>572.69</td>
      <td>106969479769264</td>
    </tr>
    <tr>
      <th>South Shannonborough</th>
      <th>Suburban</th>
      <td>135</td>
      <td>397.75</td>
      <td>72373118861919</td>
    </tr>
    <tr>
      <th>Spencertown</th>
      <th>Urban</th>
      <td>1768</td>
      <td>615.71</td>
      <td>126114546126788</td>
    </tr>
    <tr>
      <th>Stevensport</th>
      <th>Rural</th>
      <td>30</td>
      <td>159.74</td>
      <td>15628602628342</td>
    </tr>
    <tr>
      <th>Stewartview</th>
      <th>Urban</th>
      <td>1470</td>
      <td>648.42</td>
      <td>148100838345590</td>
    </tr>
    <tr>
      <th>Swansonbury</th>
      <th>Urban</th>
      <td>2176</td>
      <td>933.80</td>
      <td>151062943394537</td>
    </tr>
    <tr>
      <th>Thomastown</th>
      <th>Suburban</th>
      <td>24</td>
      <td>727.40</td>
      <td>108615188357498</td>
    </tr>
    <tr>
      <th>Tiffanyton</th>
      <th>Suburban</th>
      <td>273</td>
      <td>370.63</td>
      <td>64589955138430</td>
    </tr>
    <tr>
      <th>Torresshire</th>
      <th>Urban</th>
      <td>1820</td>
      <td>629.39</td>
      <td>133065581883609</td>
    </tr>
    <tr>
      <th>Travisville</th>
      <th>Urban</th>
      <td>851</td>
      <td>626.08</td>
      <td>76302658107954</td>
    </tr>
    <tr>
      <th>Vickimouth</th>
      <th>Urban</th>
      <td>195</td>
      <td>322.12</td>
      <td>63641072786753</td>
    </tr>
    <tr>
      <th>Webstertown</th>
      <th>Suburban</th>
      <td>416</td>
      <td>475.54</td>
      <td>70423434921161</td>
    </tr>
    <tr>
      <th>West Alexis</th>
      <th>Urban</th>
      <td>940</td>
      <td>390.46</td>
      <td>102675318141168</td>
    </tr>
    <tr>
      <th>West Brandy</th>
      <th>Urban</th>
      <td>360</td>
      <td>724.73</td>
      <td>140203050563386</td>
    </tr>
    <tr>
      <th>West Brittanyton</th>
      <th>Urban</th>
      <td>216</td>
      <td>610.47</td>
      <td>139127420368493</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <th>Urban</th>
      <td>986</td>
      <td>647.58</td>
      <td>148466691609824</td>
    </tr>
    <tr>
      <th>West Evan</th>
      <th>Suburban</th>
      <td>48</td>
      <td>324.16</td>
      <td>65347392852623</td>
    </tr>
    <tr>
      <th>West Jefferyfurt</th>
      <th>Urban</th>
      <td>1365</td>
      <td>442.53</td>
      <td>75903180763582</td>
    </tr>
    <tr>
      <th>West Kevintown</th>
      <th>Rural</th>
      <td>35</td>
      <td>150.70</td>
      <td>49015198763480</td>
    </tr>
    <tr>
      <th>West Oscar</th>
      <th>Urban</th>
      <td>319</td>
      <td>704.12</td>
      <td>131246533819841</td>
    </tr>
    <tr>
      <th>West Pamelaborough</th>
      <th>Suburban</th>
      <td>378</td>
      <td>473.19</td>
      <td>57141292201330</td>
    </tr>
    <tr>
      <th>West Paulport</th>
      <th>Suburban</th>
      <td>85</td>
      <td>565.73</td>
      <td>83223831868102</td>
    </tr>
    <tr>
      <th>West Peter</th>
      <th>Urban</th>
      <td>1891</td>
      <td>771.14</td>
      <td>143553740646342</td>
    </tr>
    <tr>
      <th>West Sydneyhaven</th>
      <th>Urban</th>
      <td>1260</td>
      <td>402.63</td>
      <td>79780212583099</td>
    </tr>
    <tr>
      <th>West Tony</th>
      <th>Suburban</th>
      <td>323</td>
      <td>562.58</td>
      <td>96522785457789</td>
    </tr>
    <tr>
      <th>Williamchester</th>
      <th>Suburban</th>
      <td>286</td>
      <td>377.06</td>
      <td>62472245620363</td>
    </tr>
    <tr>
      <th>Williamshire</th>
      <th>Urban</th>
      <td>2170</td>
      <td>836.70</td>
      <td>153068829069985</td>
    </tr>
    <tr>
      <th>Wiseborough</th>
      <th>Urban</th>
      <td>1045</td>
      <td>430.86</td>
      <td>114884919652866</td>
    </tr>
    <tr>
      <th>Yolandafurt</th>
      <th>Urban</th>
      <td>140</td>
      <td>544.11</td>
      <td>97417338184348</td>
    </tr>
    <tr>
      <th>Zimmermanmouth</th>
      <th>Urban</th>
      <td>1080</td>
      <td>679.24</td>
      <td>110849624954937</td>
    </tr>
  </tbody>
</table>
<p>125 rows × 3 columns</p>
</div>




```python
# Gives you the total # of Rides per city (125 rows), this is the x-axis of the bubble chart
groupbycity.count()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>driver_count</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>city</th>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <th>Urban</th>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <th>Urban</th>
      <td>26</td>
      <td>26</td>
      <td>26</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <th>Suburban</th>
      <td>9</td>
      <td>9</td>
      <td>9</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <th>Urban</th>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <th>Urban</th>
      <td>19</td>
      <td>19</td>
      <td>19</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Arnoldview</th>
      <th>Urban</th>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Campbellport</th>
      <th>Suburban</th>
      <td>15</td>
      <td>15</td>
      <td>15</td>
      <td>15</td>
    </tr>
    <tr>
      <th>Carrollbury</th>
      <th>Suburban</th>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Carrollfort</th>
      <th>Urban</th>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
    </tr>
    <tr>
      <th>Clarkstad</th>
      <th>Suburban</th>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
    </tr>
    <tr>
      <th>Conwaymouth</th>
      <th>Suburban</th>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Davidtown</th>
      <th>Urban</th>
      <td>21</td>
      <td>21</td>
      <td>21</td>
      <td>21</td>
    </tr>
    <tr>
      <th>Davistown</th>
      <th>Urban</th>
      <td>25</td>
      <td>25</td>
      <td>25</td>
      <td>25</td>
    </tr>
    <tr>
      <th>East Cherylfurt</th>
      <th>Suburban</th>
      <td>13</td>
      <td>13</td>
      <td>13</td>
      <td>13</td>
    </tr>
    <tr>
      <th>East Douglas</th>
      <th>Urban</th>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
    </tr>
    <tr>
      <th>East Erin</th>
      <th>Urban</th>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
    </tr>
    <tr>
      <th>East Jenniferchester</th>
      <th>Suburban</th>
      <td>19</td>
      <td>19</td>
      <td>19</td>
      <td>19</td>
    </tr>
    <tr>
      <th>East Leslie</th>
      <th>Rural</th>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
    </tr>
    <tr>
      <th>East Stephen</th>
      <th>Rural</th>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
    </tr>
    <tr>
      <th>East Troybury</th>
      <th>Rural</th>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
    </tr>
    <tr>
      <th>Edwardsbury</th>
      <th>Urban</th>
      <td>27</td>
      <td>27</td>
      <td>27</td>
      <td>27</td>
    </tr>
    <tr>
      <th>Erikport</th>
      <th>Rural</th>
      <td>8</td>
      <td>8</td>
      <td>8</td>
      <td>8</td>
    </tr>
    <tr>
      <th>Eriktown</th>
      <th>Urban</th>
      <td>19</td>
      <td>19</td>
      <td>19</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Floresberg</th>
      <th>Suburban</th>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Fosterside</th>
      <th>Urban</th>
      <td>24</td>
      <td>24</td>
      <td>24</td>
      <td>24</td>
    </tr>
    <tr>
      <th>Hernandezshire</th>
      <th>Rural</th>
      <td>9</td>
      <td>9</td>
      <td>9</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Horneland</th>
      <th>Rural</th>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Jacksonfort</th>
      <th>Rural</th>
      <td>6</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>Jacobfort</th>
      <th>Urban</th>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Jasonfort</th>
      <th>Suburban</th>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>South Roy</th>
      <th>Urban</th>
      <td>22</td>
      <td>22</td>
      <td>22</td>
      <td>22</td>
    </tr>
    <tr>
      <th>South Shannonborough</th>
      <th>Suburban</th>
      <td>15</td>
      <td>15</td>
      <td>15</td>
      <td>15</td>
    </tr>
    <tr>
      <th>Spencertown</th>
      <th>Urban</th>
      <td>26</td>
      <td>26</td>
      <td>26</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Stevensport</th>
      <th>Rural</th>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>Stewartview</th>
      <th>Urban</th>
      <td>30</td>
      <td>30</td>
      <td>30</td>
      <td>30</td>
    </tr>
    <tr>
      <th>Swansonbury</th>
      <th>Urban</th>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
    </tr>
    <tr>
      <th>Thomastown</th>
      <th>Suburban</th>
      <td>24</td>
      <td>24</td>
      <td>24</td>
      <td>24</td>
    </tr>
    <tr>
      <th>Tiffanyton</th>
      <th>Suburban</th>
      <td>13</td>
      <td>13</td>
      <td>13</td>
      <td>13</td>
    </tr>
    <tr>
      <th>Torresshire</th>
      <th>Urban</th>
      <td>26</td>
      <td>26</td>
      <td>26</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Travisville</th>
      <th>Urban</th>
      <td>23</td>
      <td>23</td>
      <td>23</td>
      <td>23</td>
    </tr>
    <tr>
      <th>Vickimouth</th>
      <th>Urban</th>
      <td>15</td>
      <td>15</td>
      <td>15</td>
      <td>15</td>
    </tr>
    <tr>
      <th>Webstertown</th>
      <th>Suburban</th>
      <td>16</td>
      <td>16</td>
      <td>16</td>
      <td>16</td>
    </tr>
    <tr>
      <th>West Alexis</th>
      <th>Urban</th>
      <td>20</td>
      <td>20</td>
      <td>20</td>
      <td>20</td>
    </tr>
    <tr>
      <th>West Brandy</th>
      <th>Urban</th>
      <td>30</td>
      <td>30</td>
      <td>30</td>
      <td>30</td>
    </tr>
    <tr>
      <th>West Brittanyton</th>
      <th>Urban</th>
      <td>24</td>
      <td>24</td>
      <td>24</td>
      <td>24</td>
    </tr>
    <tr>
      <th>West Dawnfurt</th>
      <th>Urban</th>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
    </tr>
    <tr>
      <th>West Evan</th>
      <th>Suburban</th>
      <td>12</td>
      <td>12</td>
      <td>12</td>
      <td>12</td>
    </tr>
    <tr>
      <th>West Jefferyfurt</th>
      <th>Urban</th>
      <td>21</td>
      <td>21</td>
      <td>21</td>
      <td>21</td>
    </tr>
    <tr>
      <th>West Kevintown</th>
      <th>Rural</th>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
    </tr>
    <tr>
      <th>West Oscar</th>
      <th>Urban</th>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
    </tr>
    <tr>
      <th>West Pamelaborough</th>
      <th>Suburban</th>
      <td>14</td>
      <td>14</td>
      <td>14</td>
      <td>14</td>
    </tr>
    <tr>
      <th>West Paulport</th>
      <th>Suburban</th>
      <td>17</td>
      <td>17</td>
      <td>17</td>
      <td>17</td>
    </tr>
    <tr>
      <th>West Peter</th>
      <th>Urban</th>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
    </tr>
    <tr>
      <th>West Sydneyhaven</th>
      <th>Urban</th>
      <td>18</td>
      <td>18</td>
      <td>18</td>
      <td>18</td>
    </tr>
    <tr>
      <th>West Tony</th>
      <th>Suburban</th>
      <td>19</td>
      <td>19</td>
      <td>19</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Williamchester</th>
      <th>Suburban</th>
      <td>11</td>
      <td>11</td>
      <td>11</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Williamshire</th>
      <th>Urban</th>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
    </tr>
    <tr>
      <th>Wiseborough</th>
      <th>Urban</th>
      <td>19</td>
      <td>19</td>
      <td>19</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Yolandafurt</th>
      <th>Urban</th>
      <td>20</td>
      <td>20</td>
      <td>20</td>
      <td>20</td>
    </tr>
    <tr>
      <th>Zimmermanmouth</th>
      <th>Urban</th>
      <td>24</td>
      <td>24</td>
      <td>24</td>
      <td>24</td>
    </tr>
  </tbody>
</table>
<p>125 rows × 4 columns</p>
</div>




```python
ave_fare_df = groupbycity.mean()  
```


```python
ave_fare_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>driver_count</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>city</th>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <th>Urban</th>
      <td>21.0</td>
      <td>23.928710</td>
      <td>5.351586e+12</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <th>Urban</th>
      <td>67.0</td>
      <td>20.609615</td>
      <td>3.536678e+12</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <th>Suburban</th>
      <td>16.0</td>
      <td>37.315556</td>
      <td>4.195870e+12</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <th>Urban</th>
      <td>21.0</td>
      <td>23.625000</td>
      <td>5.086800e+12</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <th>Urban</th>
      <td>49.0</td>
      <td>21.981579</td>
      <td>4.574788e+12</td>
    </tr>
  </tbody>
</table>
</div>




```python
# delete driver_count and ride_id columns because these are the average values and not what we want
del ave_fare_df["driver_count"]
```


```python
del ave_fare_df["ride_id"]
```


```python
ave_fare_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>fare</th>
    </tr>
    <tr>
      <th>city</th>
      <th>type</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <th>Urban</th>
      <td>23.928710</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <th>Urban</th>
      <td>20.609615</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <th>Suburban</th>
      <td>37.315556</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <th>Urban</th>
      <td>23.625000</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <th>Urban</th>
      <td>21.981579</td>
    </tr>
  </tbody>
</table>
</div>




```python
ave_fare_df = ave_fare_df.reset_index()
```


```python
#ave_fare_df.head()
```


```python
ave_fare_df.rename(columns={"fare":"ave_fare_percity"}, inplace=True)
```


```python
ave_fare_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>ave_fare_percity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>23.928710</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>20.609615</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>Suburban</td>
      <td>37.315556</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>23.625000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>21.981579</td>
    </tr>
  </tbody>
</table>
</div>




```python
#setup another dataframe without the type column
drive_sum_df = groupbycitynotype.sum()
```


```python
#drive_sum_df.head()
```


```python
del drive_sum_df["fare"]
```


```python
del drive_sum_df["ride_id"]
```


```python
#drive_sum_df.head()
```


```python
drive_sum_df = drive_sum_df.reset_index()
```


```python
#drive_sum_df.head()
```


```python
drive_sum_df.rename(columns={"driver_count":"total_drivers_percity"}, inplace=True)
```


```python
drive_sum_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>total_drivers_percity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>651</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>1742</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>144</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>462</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>931</td>
    </tr>
  </tbody>
</table>
</div>




```python
tot_rides_df = groupbycitynotype.count()
```


```python
#tot_rides_df.head()
```


```python
del tot_rides_df["driver_count"]
```


```python
del tot_rides_df["type"]
```


```python
del tot_rides_df["fare"]
```


```python
del tot_rides_df["ride_id"]
```


```python
#tot_rides_df.head()
```


```python
tot_rides_df = tot_rides_df.reset_index()
```


```python
tot_rides_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
# rename column from date to total_rides_percity
tot_rides_df.rename(columns={"date": "total_rides_percity"}, inplace=True)
```


```python
fare_drive = pd.merge(ave_fare_df, drive_sum_df, on = "city")
```


```python
pyber_bubble_df = pd.merge(fare_drive, tot_rides_df, on = "city")
```


```python
pyber_bubble_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>ave_fare_percity</th>
      <th>total_drivers_percity</th>
      <th>total_rides_percity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>23.928710</td>
      <td>651</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>20.609615</td>
      <td>1742</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>Suburban</td>
      <td>37.315556</td>
      <td>144</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>23.625000</td>
      <td>462</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>21.981579</td>
      <td>931</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = pyber_bubble_df
```


```python
analysis = df.groupby("type")
analysis.mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ave_fare_percity</th>
      <th>total_drivers_percity</th>
      <th>total_rides_percity</th>
    </tr>
    <tr>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Rural</th>
      <td>34.207143</td>
      <td>40.388889</td>
      <td>6.944444</td>
    </tr>
    <tr>
      <th>Suburban</th>
      <td>30.942131</td>
      <td>237.317073</td>
      <td>16.024390</td>
    </tr>
    <tr>
      <th>Urban</th>
      <td>24.603991</td>
      <td>977.287879</td>
      <td>24.621212</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dtypes
```




    city                      object
    type                      object
    ave_fare_percity         float64
    total_drivers_percity      int64
    total_rides_percity        int64
    dtype: object




```python
df.count()
```




    city                     125
    type                     125
    ave_fare_percity         125
    total_drivers_percity    125
    total_rides_percity      125
    dtype: int64




```python
# Create a scatter plot  
my_plot = df.plot(kind="scatter", x="total_rides_percity", y="ave_fare_percity", grid=True, figsize=(20,10), title="Pyber Ride Sharing Data - Total (2016)", label=df.type, sizes=(df['total_drivers_percity']))
my_plot.set_xlabel("Total Number of Rides (Per City)", fontsize=28)
my_plot.set_ylabel("Average Fare ($)", fontsize=28)
my_plot.set_title(my_plot.title.get_text(), fontsize=32)
my_plot.set_ylim(-0.25, 55)
my_plot.set_xlim(0,70)
my_plot.legend()
plt.show()
```


![png](output_46_0.png)



```python
pyber_bubble_urban_df = pyber_bubble_df[pyber_bubble_df.type =="Urban"]
```


```python
pyber_bubble_urban_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>ave_fare_percity</th>
      <th>total_drivers_percity</th>
      <th>total_rides_percity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>23.928710</td>
      <td>651</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>20.609615</td>
      <td>1742</td>
      <td>26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>23.625000</td>
      <td>462</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>21.981579</td>
      <td>931</td>
      <td>19</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Arnoldview</td>
      <td>Urban</td>
      <td>25.106452</td>
      <td>1271</td>
      <td>31</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Create a scatter plot - Urban only 
my_plot = pyber_bubble_urban_df.plot(kind="scatter", x="total_rides_percity", y="ave_fare_percity", color = "orange", grid=True, figsize=(20,10), title="Pyber Ride Sharing Data (2016 - Urban Only)", label="urban", sizes=(df['total_drivers_percity']))
my_plot.set_xlabel("Total Number of Rides (Per City)", fontsize=28)
my_plot.set_ylabel("Average Fare ($)", fontsize=28)
my_plot.set_title(my_plot.title.get_text(), fontsize=32)
my_plot.set_ylim(-0.25, 55)
my_plot.set_xlim(0,70)
my_plot.legend()
plt.show()
```


![png](output_49_0.png)



```python
df1 = pyber_bubble_urban_df
#x_axis1 = df1["total_rides_percity"].tolist()
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>ave_fare_percity</th>
      <th>total_drivers_percity</th>
      <th>total_rides_percity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>23.928710</td>
      <td>651</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>20.609615</td>
      <td>1742</td>
      <td>26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>23.625000</td>
      <td>462</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>21.981579</td>
      <td>931</td>
      <td>19</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Arnoldview</td>
      <td>Urban</td>
      <td>25.106452</td>
      <td>1271</td>
      <td>31</td>
    </tr>
  </tbody>
</table>
</div>




```python
#x_axis1 = df1["total_rides_percity"].tolist()
x_axis1 = list(df1.total_rides_percity.values)
print(len(x_axis1))
#x_axis1
y_axis1 = list(df1.ave_fare_percity.values)
print(len(y_axis1))
size1 = list(df1.total_drivers_percity.values)
print(len(size1))
```

    66
    66
    66
    


```python
pyber_bubble_rural_df = pyber_bubble_df[pyber_bubble_df.type =="Rural"]
df2 = pyber_bubble_rural_df
```


```python
# Create a scatter plot  
my_plot = df2.plot(kind="scatter", x="total_rides_percity", y="ave_fare_percity", grid=True, figsize=(20,10), title="Pyber Ride Sharing Data - Rural (2016)", label="Rural", color = "green", sizes=(df2['total_drivers_percity']))
my_plot.set_xlabel("Total Number of Rides (Per City)", fontsize=28)
my_plot.set_ylabel("Average Fare ($)", fontsize=28)
my_plot.set_title(my_plot.title.get_text(), fontsize=32)
my_plot.set_ylim(-0.25, 55)
my_plot.set_xlim(0,70)
my_plot.legend()
plt.show()
```


![png](output_53_0.png)



```python
pyber_bubble_Suburban_df = pyber_bubble_df[pyber_bubble_df.type =="Suburban"]
df3 = pyber_bubble_Suburban_df
```


```python
# Create a scatter plot  
my_plot = df3.plot(kind="scatter", x="total_rides_percity", y="ave_fare_percity", grid=True, figsize=(20,10), title="Pyber Ride Sharing Data - Suburban (2016)", label="Suburban", color = "red", sizes=(df3['total_drivers_percity']))
my_plot.set_xlabel("Total Number of Rides (Per City)", fontsize=28)
my_plot.set_ylabel("Average Fare ($)", fontsize=28)
my_plot.set_title(my_plot.title.get_text(), fontsize=32)
my_plot.set_ylim(-0.25, 55)
my_plot.set_xlim(0,70)
my_plot.legend()
plt.show()
```


![png](output_55_0.png)



```python
# This is the 2nd part of the problem
pyber_bubble_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>type</th>
      <th>ave_fare_percity</th>
      <th>total_drivers_percity</th>
      <th>total_rides_percity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Alvarezhaven</td>
      <td>Urban</td>
      <td>23.928710</td>
      <td>651</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Alyssaberg</td>
      <td>Urban</td>
      <td>20.609615</td>
      <td>1742</td>
      <td>26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Anitamouth</td>
      <td>Suburban</td>
      <td>37.315556</td>
      <td>144</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Antoniomouth</td>
      <td>Urban</td>
      <td>23.625000</td>
      <td>462</td>
      <td>22</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aprilchester</td>
      <td>Urban</td>
      <td>21.981579</td>
      <td>931</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
</div>




```python
pyber_bubble_df.count()
```




    city                     125
    type                     125
    ave_fare_percity         125
    total_drivers_percity    125
    total_rides_percity      125
    dtype: int64




```python
groupbytype = pyber_bubble_df.groupby(["type"])

```


```python
pie_df = groupbytype.sum()
pie_dfIndex = pie_df.reset_index()
pie_dfIndex
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>type</th>
      <th>ave_fare_percity</th>
      <th>total_drivers_percity</th>
      <th>total_rides_percity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Rural</td>
      <td>615.728572</td>
      <td>727</td>
      <td>125</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Suburban</td>
      <td>1268.627391</td>
      <td>9730</td>
      <td>657</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Urban</td>
      <td>1623.863390</td>
      <td>64501</td>
      <td>1625</td>
    </tr>
  </tbody>
</table>
</div>




```python
tot_d = pie_df["total_drivers_percity"]
tot_r = pie_df["total_rides_percity"]
tot_d
tot_r
```




    type
    Rural        125
    Suburban     657
    Urban       1625
    Name: total_rides_percity, dtype: int64




```python
# Create a bar chart based off of the group series from before
ax1 = plt.subplot(121, aspect="equal")
tot_dpie = tot_d.plot(kind='pie', ax=ax1, autopct="%1.1f%%", figsize=(9,9), shadow=False, startangle=90)

# Set the xlabel and ylabel using class methods
tot_dpie.set_xlabel("Type of City")
tot_dpie.set_ylabel("Total Drivers")
plt.show()
```


![png](output_61_0.png)



```python
# Create a bar chart based off of the group series from before
ax1 = plt.subplot(121, aspect="equal")
tot_rpie = tot_r.plot(kind='pie', ax=ax1, autopct="%1.1f%%", figsize=(9,9), shadow=False, startangle=90)

# Set the xlabel and ylabel using class methods
tot_rpie.set_xlabel("Type of City")
tot_rpie.set_ylabel("Total Riders")
plt.show()
```


![png](output_62_0.png)



```python
groupbycity = merged_cityride_df.groupby(["city", "type"])
tot_fare = groupbycity.sum()
tot_fare.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>driver_count</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>city</th>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alvarezhaven</th>
      <th>Urban</th>
      <td>651</td>
      <td>741.79</td>
      <td>165899161874789</td>
    </tr>
    <tr>
      <th>Alyssaberg</th>
      <th>Urban</th>
      <td>1742</td>
      <td>535.85</td>
      <td>91953627077845</td>
    </tr>
    <tr>
      <th>Anitamouth</th>
      <th>Suburban</th>
      <td>144</td>
      <td>335.84</td>
      <td>37762826439863</td>
    </tr>
    <tr>
      <th>Antoniomouth</th>
      <th>Urban</th>
      <td>462</td>
      <td>519.75</td>
      <td>111909606921566</td>
    </tr>
    <tr>
      <th>Aprilchester</th>
      <th>Urban</th>
      <td>931</td>
      <td>417.65</td>
      <td>86920968698689</td>
    </tr>
  </tbody>
</table>
</div>




```python
tot_f = tot_fare.groupby("type")
tot_f = tot_f.sum()
```


```python
tot_f
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>driver_count</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
    <tr>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Rural</th>
      <td>727</td>
      <td>4255.09</td>
      <td>658729360193746</td>
    </tr>
    <tr>
      <th>Suburban</th>
      <td>9730</td>
      <td>20335.69</td>
      <td>3139583688401015</td>
    </tr>
    <tr>
      <th>Urban</th>
      <td>64501</td>
      <td>40078.34</td>
      <td>7890194186030600</td>
    </tr>
  </tbody>
</table>
</div>




```python
tot_fare = tot_f["fare"]
tot_fare
```




    type
    Rural        4255.09
    Suburban    20335.69
    Urban       40078.34
    Name: fare, dtype: float64




```python
# Create a bar chart based off of the group series from before
ax1 = plt.subplot(121, aspect="equal")
tot_fpie = tot_fare.plot(kind='pie', ax=ax1, autopct="%1.1f%%", figsize=(9,9), shadow=False, startangle=90)

# Set the xlabel and ylabel using class methods
tot_fpie.set_xlabel("Type of City")
tot_fpie.set_ylabel("Total Fare")
plt.show()
```


![png](output_67_0.png)



```python
analysis = df.groupby("type")
analysis.mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ave_fare_percity</th>
      <th>total_drivers_percity</th>
      <th>total_rides_percity</th>
    </tr>
    <tr>
      <th>type</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Rural</th>
      <td>34.207143</td>
      <td>40.388889</td>
      <td>6.944444</td>
    </tr>
    <tr>
      <th>Suburban</th>
      <td>30.942131</td>
      <td>237.317073</td>
      <td>16.024390</td>
    </tr>
    <tr>
      <th>Urban</th>
      <td>24.603991</td>
      <td>977.287879</td>
      <td>24.621212</td>
    </tr>
  </tbody>
</table>
</div>



Provide 3 written descriptions of 3 observable trands based on the data:

From the Bubble Chart:
--> Rural cities have the highest average fare, but the lowest total fares.  Their total # of drivers are less.
The Urban are in the right most of the two categories of Rural and Suburban, the urban have large total # of drivers and their average fare is lowest, and their total # of drives are high.

From the Pie Chart:
-->Urban cities have the most total drivers, total riders, and total fares per city, followed by suburban and then rural – which makes sense.  Since more business for rides in urban cities vs. suburban and rural.

From the table analysis:
--> Average fares by Urban cities are lowest.  Although the Urban cities have the highest total fare revenue. 


